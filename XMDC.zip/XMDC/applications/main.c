/*
 * Copyright (c) 2006-2025, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-05-13     RT-Thread    first version
 */

#include <rtthread.h>

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

int main(void)
{
    int count = 1;

    while (count++)
    {
        LOG_D("Hello RT-Thread!");
        rt_thread_mdelay(1000);
    }

    return RT_EOK;
}


//发送@——》rpi-》feeding=-4-》STM32EXITBOOT-》stm32u3CCC-》发送app
typedef void (*iapfun)(void);  // 定义函数指针类型，用于跳转到 App
// 跳转到应用程序
void iap_load_app(uint32_t addr)
{
    // 检查栈顶地址是否合法（必须在 RAM 范围内）
    if ((*(volatile uint32_t*)addr & 0x2FFE0000) != 0x20000000) {
        printf("Invalid Stack Pointer!\r\n");
        return;
    }

    __disable_irq();  // 关闭所有中断
     SCB->VTOR =0x08000000;  // 设置中断向量表偏移
    __set_MSP(*(volatile uint32_t*)addr);  // 设置主堆栈指针

    iapfun app_entry = (iapfun)*(volatile uint32_t*)(addr + 4);  // 获取 App 复位函数地址
    printf("Jumping to BOOT at 0x%08X...\r\n", addr);
    delay_ms(50);

    USART_Cmd(USART1, DISABLE);  // 关闭串口，防止干扰
        USART_Cmd(USART3, DISABLE);  // 关闭串口，防止干扰
                                                                //  关闭看门狗、EXTIX_Init();//外部中断初始化
        /***********************************************************
        如果在boot中使用了某个中断。那么在跳转APP前要将其关闭相关资源，
        否则会导致中断优先级冲突，导致APP可以正常初始化但是无法进入while
        ************************************************************/

    app_entry();  // 跳转到 App
}

/***************************主函数初始化**********************************/
void main_init()//总初始化
{
    SCB->VTOR = 0x08003000;  // 指向 APP 的中断向量表
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//设置中断优先级分组为组2：2位抢占优先级，2位响应优先级
    delay_init();            //延时函数初始化
    uart_init(115200);   //串口1初始化为115200
    uart3_init(115200);  //串口3初始化为115200
    AD_Init();//AD采集初始化
    GY39_Init();//gy39初始化
    DS18B20_Init();//DS18B20初始化
    LED_Int(GPIOC,GPIO_Pin_13,RCC_APB2Periph_GPIOC);//工作指示灯初始化
    Relay_init();//继电器初始化
    LCD_Init();//LCD初始化
    LCD_Fill(0,0,LCD_W,LCD_H,BLACK);//LCD底色设置
    EXTIX_Init();//外部中断初始化
    delay_ms(100);//等待完成
    user_debug("init suc ...");
}
int main(void)
{
    //初始化
    main_init();
    //创建开始任务
    xTaskCreate((TaskFunction_t )start_task,            //任务函数
                (const char*    )"start_task",          //任务名称
                (uint16_t       )START_STK_SIZE,        //任务堆栈大小
                (void*          )NULL,                  //传递给任务函数的参数
                (UBaseType_t    )START_TASK_PRIO,       //任务优先级
                (TaskHandle_t*  )&StartTask_Handler);   //任务句柄
        user_debug("create start task suc ...");
    vTaskStartScheduler();          //开启任务调度
}

//开始任务任务函数
void start_task(void *pvParameters)
{
    taskENTER_CRITICAL();           //进入临界区
    //创建LED0任务
    xTaskCreate((TaskFunction_t )led0_task,
                (const char*    )"led0_task",
                (uint16_t       )LED0_STK_SIZE,
                (void*          )NULL,
                (UBaseType_t    )LED0_TASK_PRIO,
                (TaskHandle_t*  )&LED0Task_Handler);
    //创建LED1任务
    xTaskCreate((TaskFunction_t )led1_task,
                (const char*    )"led1_task",
                (uint16_t       )LED1_STK_SIZE,
                (void*          )NULL,
                (UBaseType_t    )LED1_TASK_PRIO,
                (TaskHandle_t*  )&LED1Task_Handler);

    //创建DEBUG任务
    xTaskCreate((TaskFunction_t )debug_task,
                (const char*    )"debug_task",
                (uint16_t       )DEBUG_STK_SIZE,
                (void*          )NULL,
                (UBaseType_t    )DEBUG_TASK_PRIO,
                (TaskHandle_t*  )&DEBUGTask_Handler);

    vTaskDelete(StartTask_Handler); //删除开始任务
    taskEXIT_CRITICAL();            //退出临界区
}
u16 ph_data[12];
u8 data_x=0;
//task1任务函数
void task1_task(void *pvParameters)
{
      IWDG_Init(4,1031);//看门狗初始化550*3=1650ms溢出时间
    while(1)
    {
                LED0=~LED0;//工作指示灯
                IWDG_Feed();//喂看门狗
                Read_GY39();//获取水外环境数据
                watertemp=DS18B20_Get_Temp_Filtered();//获取水温(C)
                TDS_Value=TDS_Value_Conversion(watertemp);//获取导电率TDS(ppm)
                PH_Value=PH_Value_Conversion();//获取酸碱度PH(ph)
                ORP_Value=ORP_Value_Conversion(0.5);//获取氧化还原性ORP(mv)
                TU_Value=TU_Value_Conversion(watertemp);//获取浑浊度(NTU)
                waterlevel=WaterLevel_Conversion();//获取水位(cm)


                Relay_con();//继电器控制逻辑


                rt_thread_mdelay(500);
    }
}
u8 dis_debug=0;
//task2任务函数
void led1_task(void *pvParameters)
{
        char tx_str[100];
        u8 run_task2_t=0;
        while(1)
        {
            vTaskDelay(100);    run_task2_t++;
            if(run_task2_t%15==0)
            {
                if(fx==3)
                    sprintf(tx_str, "T:%d;H=%.2f;P:%.2f;A:%.2f;L:%.2f;WT:%.2f;TDS:%.2f;PH:%.2f;ORP:%.2f;TU:%.2f;WL:%.2f;\r\n",
                    (u16)T, H, PA,A,L,  watertemp, TDS_Value, PH_Value, ORP_Value,TU_Value,waterlevel);
                else
                {
                    sprintf(tx_str, "T:%d;H=%.2f;P:%.2f;A:%.2f;L:%.2f;WT:%.2f;TDS:%.2f;PH:%.2f;ORP:%.2f;TU:%.2f;WL:%.2f;F:%d;\r\n",
                    (u16)T, H, PA,A,L,  watertemp, TDS_Value, PH_Value, ORP_Value,TU_Value,waterlevel,fx);
                    fx=3;
                }
                usart_sendString(USART3,tx_str);
            }

            if(dis_debug<20){display_optimized();if (!GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))dis_debug++;}
            else if(dis_debug==21)  DisplayDebugInfoOnLCD();
            else {LCD_Fill(0, 0, LCD_W, LCD_H, WHITE);dis_debug++;}


            if(feeding==-4)
            {

                taskENTER_CRITICAL();           //进入临界区
                iap_load_app(0x8000000);
                taskEXIT_CRITICAL();            //退出临界区
            }


        }
}


void debug_task(void *pvParameters)
{

        print_clock_info();
        while(1)
        {
            vTaskDelay(1500);
            RunTaskInfo();
            // 传感器数据展示
            printf("\r\n-------- [传感器数据] --------\r\n");
            user_info("┌───────────────────┐");
            user_info("│ 参数         │ 值        │ 单位    │");
            user_info("├───────────────────┤");
            user_info("│ 环境温度     │ %-8.2f │ °C      │", T);
            user_info("│ 环境湿度     │ %-8.2f │ %%        │", H);
            user_info("│ 大气压       │ %-8.2f │ hPa      │", PA);
            user_info("│ 光照强度     │ %-8.2f │ Lux      │", L);
            user_info("│ 水温         │ %-8.2f │ °C      │", watertemp);
            user_info("│ PH值         │ %-8.2f │ ph       │", PH_Value);
            user_info("│ TDS          │ %-8.2f │ ppm      │", TDS_Value);
            user_info("│ ORP          │ %-8.2f │ mV       │", ORP_Value);
            user_info("│ 浊度         │ %-8.2f │ NTU      │", TU_Value);
            user_info("│ 水位         │ %-8.2f │ cm       │", waterlevel);
            user_info("│ 喂食状态     │ %-8d │ 个       │", feeding );
            user_info("└───────────────────┘");
    }
}


// 接收上位机数据
void USART3_IRQHandler(void)
{
    if (USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)  // 检查是否为接收中断
    {
        char received_char = USART_ReceiveData(USART3);     // 获取接收到的字符
        if (received_char != ';')  // 如果不是结束符，继续存储字符
        {
            if (rx_index < RX_BUFFER_SIZE - 1)  // 防止缓冲区溢出
            {
                rx_buffer[rx_index++] = received_char;  // 存储字符并移动索引
            }
        }
        else  // 如果接收到结束符，表示接收完毕
        {
            rx_buffer[rx_index] = '\0';  // 为字符串添加结束符
            rx_index = 0;  // 重置索引，准备接收下一条数据
            // 处理接收到的数据，这里可以解析时间,5 表示的是前缀 "time:" 的字符个数
            if (strncmp(rx_buffer, "time:", 5) == 0)  // 检查数据是否以 "time:" 开头
            {
                // 解析时间字符串并赋值给整数变量
               sscanf(rx_buffer + 5, "%d-%d-%d-%d-%d-%d", &year, &month, &day, &hour, &minute, &feeding);

            }
        }
    }
}

// 外部中断服务程序 (处理PB8到PB14)
void EXTI9_5_IRQHandler(void)
{
    delay_ms(10); // 消抖

    if (EXTI_GetITStatus(EXTI_Line8) != RESET)  // PB8
    {
        if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8) == 0)  // 按键按下
        {
           Relay1=~Relay1;
                    dis_debug=0;
                    user_debug("中断11111");

        }
        EXTI_ClearITPendingBit(EXTI_Line8);  // 清除中断标志位
    }

    if (EXTI_GetITStatus(EXTI_Line9) != RESET)  // PB9
    {
        if  (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8) == 0)   // 按键按下
        {
            Relay4=~Relay4;
                        user_debug("中断11111");
        }
        EXTI_ClearITPendingBit(EXTI_Line9);  // 清除中断标志位
    }
}

void EXTI15_10_IRQHandler(void)
{
    delay_ms(10); // 消抖

    if (EXTI_GetITStatus(EXTI_Line13) != RESET)  // PB13
    {
        if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13) == 0)  // 按键按下
        {
           Relay2=~Relay2;
        }
        EXTI_ClearITPendingBit(EXTI_Line13);  // 清除中断标志位
    }

    if (EXTI_GetITStatus(EXTI_Line14) != RESET)  // PB14
    {
        if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14) == 0)  // 按键按下
        {
           Relay3=~Relay3;
        }
        EXTI_ClearITPendingBit(EXTI_Line14);  // 清除中断标志位
    }
}


