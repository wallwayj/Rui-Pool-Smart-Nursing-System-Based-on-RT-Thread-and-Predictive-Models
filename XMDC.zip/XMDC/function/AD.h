/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-05-13     wallwayj       the first version
 */
#ifndef FUNCTION_AD_H_
#define FUNCTION_AD_H_



#endif /* FUNCTION_AD_H_ */
