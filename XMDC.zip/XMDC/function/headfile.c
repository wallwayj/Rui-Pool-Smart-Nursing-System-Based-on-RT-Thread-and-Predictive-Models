#include"headfile.h"


TaskHandle_t StartTask_Handler,LED0Task_Handler,LED1Task_Handler,DEBUGTask_Handler;//������
bme Bme={9800,20,30,3210};	//ˮ��ԭʼ����
int year, month, day, hour, minute;//ʱ��
float T=20,H=45,A=3210,PA=9887,L=123;////ˮ���˲�������
float watertemp,TDS_Value,PH_Value,ORP_Value,TU_Value,waterlevel;//ˮ������
int feeding=0,fx=3;//�̵������Ʊ�־λ
char rx_buffer[RX_BUFFER_SIZE];  // ���ջ�����
volatile int rx_index = 0;       // ��ǰ���յ�����������



void Read_GY39()//��ȡGY39���ݾ�
{
		u8  raw_data[48]={0};
		uint16_t data_16[2]={0};
		if(Single_ReadI2C(0xb6,0x04,raw_data,10))
		{
			Bme.Temp=((raw_data[0]<<8)|raw_data[1]);
			data_16[0]=(((uint16_t)raw_data[2])<<8)|raw_data[3];
			data_16[1]=(((uint16_t)raw_data[4])<<8)|raw_data[5];
			Bme.P=((((uint32_t)data_16[0])<<16)|data_16[1]);
			Bme.Hum=((raw_data[6]<<8)|raw_data[7]);
			Bme.Alt=(raw_data[8]<<8)|raw_data[9];
		}
		if(Single_ReadI2C(0xb6,0x00,raw_data,4))
		data_16[0]=(((uint16_t)raw_data[0])<<8)|raw_data[1];
		data_16[1]=(((uint16_t)raw_data[2])<<8)|raw_data[3];
		T=Bme.Temp/100.0;
		H=Bme.Hum/100.0;
		PA=Bme.P/100;
		A=Bme.Alt/1.0;
		L=(((((uint32_t)data_16[0])<<16)|data_16[1]))/100.0;
} 

void display_optimized(void) 
{
    static u8 ch = 0;
    static char dis_str[20];
		
    if (ch<dis_run/2) 
		{
			 if(!ch)
			 {
					LCD_Fill(0, 0, SCREEN_W, SCREEN_H, BG_COLOR);  // ���� + ������
					LCD_Fill(0, 0, SCREEN_W, TITLE_H, PANEL_COLOR); // ������
					LCD_ShowChinese(0, 4, (u8*)"������ֳ���ϵͳ", TITLE_COLOR, PANEL_COLOR, 16, 1);
			 }
        // ��һҳ: ����������Ƭ
        const char *labels[] = {"�¶�", "ʪ��", "��ǿ", "��ѹ", "����", "ˮλ"};
        float values[]      = {T, H, L, PA, A, waterlevel};
        const char *units[] = {"C", "%", "lux", "Pa", "m", "cm"};
        for (int i = 0; i < COLS * ROWS; i++) 
				{
						int row = i / COLS;
						int col = i % COLS;
						u16 x0 = MARGIN + col * (CARD_W + MARGIN);
						u16 y0 = TITLE_H + MARGIN + row * (CARD_H + MARGIN);
						u16 x1 = x0 + CARD_W;
						u16 y1 = y0 + CARD_H;
						if(!ch)
						{							
							// ���ƿ�Ƭ���� & �߿�
							LCD_Fill(x0, y0, x1, y1, CARD_BG);
							LCD_DrawRectangle(x0, y0, x1, y1, ACCENT_COLOR);
							// ��ǩ
							LCD_ShowChinese(x0 + 4, y0 + 4, (u8*)labels[i], ACCENT_COLOR, CARD_BG, 16, 0);
						}
							// ��ֵ
						sprintf(dis_str, "%.0f%s", values[i], units[i]);
						LCD_ShowString(x0 + 4, y0 + CARD_H / 2, (const u8*)dis_str, TEXT_COLOR, CARD_BG, 12, 0);
        }
    } 
		else  
		{
				if (ch == dis_run/2)
				{
						LCD_Fill(0, 0, LCD_W, LCD_H, CARD_BG);  // ���� + ����

						// �ָ���Y���꣨ÿ��߶�ΪITEM_H��
						const u8 ITEM_H = 20;
						const u8 LINE_H = ITEM_H - 2;

						// ��ʾʱ�����
						LCD_ShowChinese(0, 0, (u8*)"ʱ�䣺", TITLE_COLOR, PANEL_COLOR, 16, 0);
						LCD_DrawLine(0, LINE_H, LCD_W, LINE_H, ACCENT_COLOR);

						// ��ʾ�����ǩ
						const char *eng_labels[] = { "TDS: ", "ORP: ", "TU: ", "PH: " };
						const char *units[]      = { "ppm", "mv", "ntu", "" };
						const float values[]     = { TDS_Value, ORP_Value, TU_Value, PH_Value };
						const u8 label_y[]       = { 40, 60, 80, 100 };

						LCD_ShowChinese(0, 20, (u8*)"ˮ�£�", ACCENT_COLOR, CARD_BG, 16, 1);
						LCD_DrawLine(0, 38, LCD_W, 38, ACCENT_COLOR);

						for (int i = 0; i < 4; i++) {
								LCD_ShowString(0, label_y[i], (const u8*)eng_labels[i], ACCENT_COLOR, CARD_BG, 16, 0);
								sprintf(dis_str, "%.2f%s", values[i], units[i]);
								LCD_ShowString(48, label_y[i], (const u8*)dis_str, TEXT_COLOR, CARD_BG, 16, 0);
								LCD_DrawLine(0, label_y[i] + 18, LCD_W, label_y[i] + 18, ACCENT_COLOR);
						}

						// ���ر�ǩ
						LCD_ShowChinese(0, 120, (u8*)"Ͷʳ��", ACCENT_COLOR, CARD_BG, 16, 0);
						LCD_ShowChinese(66, 120, (u8*)"Ͷ�ϣ�", ACCENT_COLOR, CARD_BG, 16, 0);
						LCD_DrawLine(0, 138, LCD_W, 138, ACCENT_COLOR);
						LCD_ShowChinese(0, 140, (u8*)"ˮ����", ACCENT_COLOR, CARD_BG, 16, 0);
						LCD_ShowChinese(66, 140, (u8*)"���⣺", ACCENT_COLOR, CARD_BG, 16, 0);
				}

				// ʱ������
				sprintf(dis_str, "%d-%d-%d %02d:%02d", year, month, day, hour, minute);
				LCD_ShowString(48, 0, (const u8*)dis_str, TITLE_COLOR, PANEL_COLOR, 16, 0);

				// ˮ������
				sprintf(dis_str, "%.2fC", watertemp);
				LCD_ShowString(48, 20, (const u8*)dis_str, TEXT_COLOR, CARD_BG, 16, 0);

				// ����״ֵ̬��ʾ������ɫ��
				LCD_ShowChinese(40, 120, Relay4 ? (u8*)"��" : (u8*)"��", Relay4 ? GREEN : RED, CARD_BG, 16, 0);
				LCD_ShowChinese(104, 120, Relay3 ? (u8*)"��" : (u8*)"��", Relay3 ? GREEN : RED, CARD_BG, 16, 0);
				LCD_ShowChinese(40, 140, Relay2 ? (u8*)"��" : (u8*)"��", Relay2 ? GREEN : RED, CARD_BG, 16, 0);
				LCD_ShowChinese(104, 140, Relay1 ? (u8*)"��" : (u8*)"��", Relay1 ? GREEN : RED, CARD_BG, 16, 0);
		}
		ch==dis_run?ch=0:ch++;
}


void Relay_con()
{
		static u8 flag=0,ci=6;

		if(feeding/1000==3)flag=1;
		else if(feeding/1000==1)		Relay4=1;else if(feeding/1000==2)		{Relay4=0;feeding-=2000;fx=feeding;}
		else flag=0;
		if(feeding/100%10==1)	Relay3=1;else if(feeding/100%10==2) {Relay3=0;feeding-=200;fx=feeding;}
		if(feeding/10%10==1)	Relay2=1;else if(feeding/10%10==2)	{Relay2=0;feeding-=20;fx=feeding;}
		if(feeding%10==1)			Relay1=1;else if(feeding%10==2)			{Relay1=0;feeding-=2;fx=feeding;}
		
		if(flag==1)
		{
			Relay4=1;ci=0;
		}
		else if(ci<2)
		{			
			Relay4=0;ci++;
		}
}
 RCC_ClocksTypeDef clocks;
void print_clock_info(void)
{
   
    RCC_GetClocksFreq(&clocks);
    printf("System Clock Information:\r\n");
    printf("SYSCLK_Frequency = %u Hz\r\n", clocks.SYSCLK_Frequency);
    printf("HCLK_Frequency   = %u Hz\r\n", clocks.HCLK_Frequency);
    printf("PCLK1_Frequency  = %u Hz\r\n", clocks.PCLK1_Frequency);
    printf("PCLK2_Frequency  = %u Hz\r\n", clocks.PCLK2_Frequency);
}
static size_t freeHeap,minEverFreeHeap;
static	UBaseType_t h_max0,h_max1,h_max2;
void RunTaskInfo()
{
		char RunTimeInfo[400];       //������������ʱ����Ϣ

		freeHeap = xPortGetFreeHeapSize();	// ��ȡ��ǰʣ����ڴ�
		minEverFreeHeap = xPortGetMinimumEverFreeHeapSize();	// ��ȡ��ʷ��Сʣ����ڴ�
		printf("��ǰʣ����ڴ�: %u, ��ʷ��Сʣ����ڴ�: %u\t",freeHeap, minEverFreeHeap);
		h_max0=uxTaskGetStackHighWaterMark(LED0Task_Handler) ;
		h_max1=uxTaskGetStackHighWaterMark(LED1Task_Handler) ;
		h_max2=uxTaskGetStackHighWaterMark(DEBUGTask_Handler) ;
		printf("LED0Taskʹ����%u�ֽڣ�LED1Taskʹ����%u�ֽڣ�DEBUGTaskʹ����%u�ֽ�\r\n", LED0_STK_SIZE-(int)h_max0,LED1_STK_SIZE-(int)h_max1,DEBUG_STK_SIZE-(int)h_max2); 
		vTaskGetRunTimeStats(RunTimeInfo);		//��ȡ��������ʱ����Ϣ
		printf("������\t\t����ʱ��\t������ռ�ٷֱ�\r\n%s\r\n",RunTimeInfo);
}

    char buf[64];
void DisplayDebugInfoOnLCD(void)
{
    sprintf(buf, "SYSCLK: %u Hz", clocks.SYSCLK_Frequency);
    LCD_ShowString(0, 0, (u8*)buf, BLACK, WHITE, 16, 0);

    sprintf(buf, "HCLK:   %u Hz", clocks.HCLK_Frequency);
    LCD_ShowString(0, 16, (u8*)buf, BLACK, WHITE, 16, 0);

    sprintf(buf, "PCLK1:  %u Hz", clocks.PCLK1_Frequency);
    LCD_ShowString(0, 32, (u8*)buf, BLACK, WHITE, 16, 0);

    sprintf(buf, "PCLK2:  %u Hz", clocks.PCLK2_Frequency);
    LCD_ShowString(0, 48, (u8*)buf, BLACK, WHITE, 16, 0);

    // �ڴ���Ϣ
    sprintf(buf, "FreeHeap: %u", (unsigned int)freeHeap);
    LCD_ShowString(0, 64, (u8*)buf, BLACK, WHITE, 16, 0);

    sprintf(buf, "MinHeap:  %u", (unsigned int)minEverFreeHeap);
    LCD_ShowString(0, 80, (u8*)buf, BLACK, WHITE, 16, 0);

    // ������ʹ��ջ��С
    sprintf(buf, "TASK1: %u B", (unsigned int)(h_max0));
    LCD_ShowString(0, 96, (u8*)buf, BLACK, WHITE, 16, 0);

    sprintf(buf, "TASK2: %u B", (unsigned int)(h_max1));
    LCD_ShowString(0, 112, (u8*)buf, BLACK, WHITE, 16, 0);

    sprintf(buf, "DEBUG: %u B", (unsigned int)(h_max2));
    LCD_ShowString(0, 128, (u8*)buf, BLACK, WHITE, 16, 0);
}
