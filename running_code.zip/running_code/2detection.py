#!/usr/bin/python3
# -*- encoding: utf-8 -*-
import threading
import gi
gi.require_version('Gst', '1.0')
from gi.repository import Gst, GLib
import os
import argparse
import numpy as np
import setproctitle
import cv2
import hailo
import threading
from hailo_rpi_common import (
    get_default_parser,
    QUEUE,
    get_caps_from_pad,
    get_numpy_from_buffer,
    GStreamerApp,
    app_callback_class,
)
import sys

from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import pandas as pd
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt


import deal_data
import lstm
import myaila

my_frame = None  # 全局变量来存储帧
# -----------------------------------------------------------------------------------------------
# 用户自定义类，用于回调函数中
# -----------------------------------------------------------------------------------------------
class user_app_callback_class(QObject, app_callback_class):
    frame_ready = pyqtSignal(np.ndarray)  # 定义一个信号，传递处理好的帧
    def __init__(self):
        super().__init__()
        self.new_variable = 42  # 定义一个新的变量示例
        self.use_frame = True      # 添加用于存储当前帧的变量

    def new_function(self):  # 定义一个新的方法示例
        return "生命的意义是: "

# -----------------------------------------------------------------------------------------------
# 用户自定义的回调函数
# -----------------------------------------------------------------------------------------------
def app_callback(pad, info, user_data):
    global my_frame
    buffer = info.get_buffer()
    if buffer is None:
        return Gst.PadProbeReturn.OK

    user_data.increment()
    string_to_print = f"帧计数: {user_data.get_count()}\n"

    format, width, height = get_caps_from_pad(pad)
    frame = None
    # print(f"user_data.use_frame: {user_data.use_frame}")
    if user_data.use_frame:
        frame = get_numpy_from_buffer(buffer, format, width, height)

    # 获取 ROI 并检测物体
    roi = hailo.get_roi_from_buffer(buffer)
    detections = roi.get_objects_typed(hailo.HAILO_DETECTION)

    detection_count = 0
    for detection in detections:
        label = detection.get_label()
        bbox = detection.get_bbox()  # 获取边界框
        confidence = detection.get_confidence()
        # 如果检测到 "person"，计数并输出
        if label == "fish":
            string_to_print += f"检测到: {label} 置信度: {confidence:.2f}\n"
            detection_count += 1
        # 画出识别框
        xmin, ymin, width, height = int(bbox.xmin() * frame.shape[1]), int(bbox.ymin() * frame.shape[0]), int(bbox.width() * frame.shape[1]), int(bbox.height() * frame.shape[0])
        cv2.rectangle(frame, (xmin, ymin), (xmin + width, ymin + height), (0, 255, 0), 2)
        cv2.putText(frame, f"{label} {confidence:.2f}", (xmin, ymin - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (36,255,12), 1)

    if user_data.use_frame:
        cv2.putText(frame, f"Num: {detection_count}", (20, 180), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255, 255), 1)
        #cv2.putText(frame, f"{user_data.new_function()} {user_data.new_variable}", (100, 260), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        user_data.frame_ready.emit(frame)
        frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        my_frame = frame
    
    # print(string_to_print)
    return Gst.PadProbeReturn.OK

# -----------------------------------------------------------------------------------------------
# 用户定义的 Gstreamer 应用
# -----------------------------------------------------------------------------------------------
class GStreamerDetectionApp(GStreamerApp):
    def __init__(self, args, user_data):
        super().__init__(args, user_data)
        self.batch_size = 2
        self.network_width = 640
        self.network_height = 640
        self.network_format = "RGB"
        nms_score_threshold = 0.3
        nms_iou_threshold = 0.45

        new_postprocess_path = os.path.join(self.current_path, '../resources/libyolo_hailortpp_post.so')
        if os.path.exists(new_postprocess_path):
            self.default_postprocess_so = new_postprocess_path
        else:
            self.default_postprocess_so = os.path.join(self.postprocess_dir, 'libyolo_hailortpp_post.so')

        if args.hef_path is not None:
            self.hef_path = args.hef_path
        elif args.network == "yolov6n":
            self.hef_path = os.path.join(self.current_path, '../resources/yolov6n.hef')
        elif args.network == "yolov8s":
            self.hef_path = os.path.join(self.current_path, '../resources/yolov8s_h8l.hef')
        elif args.network == "yolox_s_leaky":
            self.hef_path = os.path.join(self.current_path, '../resources/yolox_s_leaky_h8l_mz.hef')
        else:
            assert False, "无效的网络类型"

        if args.labels_json is not None:
            self.labels_config = f' config-path={args.labels_json} '
        else:
            self.labels_config = ''

        self.app_callback = app_callback

        self.thresholds_str = (
            f"nms-score-threshold={nms_score_threshold} "
            f"nms-iou-threshold={nms_iou_threshold} "
            f"output-format-type=HAILO_FORMAT_TYPE_FLOAT32"
        )

        setproctitle.setproctitle("Hailo Detection App")
        self.create_pipeline()

    def get_pipeline_string(self):
        if self.source_type == "rpi":
            source_element = (
                "libcamerasrc name=src_0 ! "
                f"video/x-raw, format={self.network_format}, width=1536, height=864 ! "
                + QUEUE("queue_src_scale")
                + "videoscale ! "
                f"video/x-raw, format={self.network_format}, width={self.network_width}, height={self.network_height}, framerate=30/1 ! "
            )
        elif self.source_type == "usb":
            source_element = (
                f"v4l2src device={self.video_source} name=src_0 ! "
                "video/x-raw, width=640, height=480, framerate=30/1 ! "
            )
        else:
            source_element = (
                f"filesrc location=\"{self.video_source}\" name=src_0 ! "
                + QUEUE("queue_dec264")
                + " qtdemux ! h264parse ! avdec_h264 max-threads=2 ! "
                " video/x-raw, format=I420 ! "
            )
        source_element += QUEUE("queue_scale")
        source_element += "videoscale n-threads=2 ! "
        source_element += QUEUE("queue_src_convert")
        source_element += "videoconvert n-threads=3 name=src_convert qos=false ! "
        source_element += f"video/x-raw, format={self.network_format}, width={self.network_width}, height={self.network_height}, pixel-aspect-ratio=1/1 ! "

        pipeline_string = (
            "hailomuxer name=hmux "
            + source_element
            + "tee name=t ! "
            + QUEUE("bypass_queue", max_size_buffers=20)
            + "hmux.sink_0 "
            + "t. ! "
            + QUEUE("queue_hailonet")
            + "videoconvert n-threads=3 ! "
            f"hailonet hef-path={self.hef_path} batch-size={self.batch_size} {self.thresholds_str} force-writable=true ! "
            + QUEUE("queue_hailofilter")
            + f"hailofilter so-path={self.default_postprocess_so} {self.labels_config} qos=false ! "
            + QUEUE("queue_hmuc")
            + "hmux.sink_1 "
            + "hmux. ! "
            + QUEUE("queue_hailo_python")
            + QUEUE("queue_user_callback")
            + "identity name=identity_callback ! "
            + QUEUE("queue_hailooverlay")
            + "hailooverlay ! "
            + QUEUE("queue_videoconvert")
            + "videoconvert n-threads=3 qos=false ! "
            + QUEUE("queue_hailo_display")
            #+ f"fpsdisplaysink video-sink={self.video_sink} name=hailo_display sync={self.sync} text-overlay={self.options_menu.show_fps} signal-fps-measurements=true " 
            + "fakesink name=output_sink sync=true"
        )
        print(pipeline_string)
        return pipeline_string
class PlotCanvas(FigureCanvas):

    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)  # 创建绘图区域
        super().__init__(fig)

    def plot(self, data, split_index, title,unit):
        # 清除之前的绘图
        self.axes.clear()

        # 前70%的数据作为Real（绿色）
        real_data = data[:split_index]
        self.axes.plot(real_data, color='green', label='Real')

        # 后30%的数据作为Prediction（蓝色）
        prediction_data = data[split_index:]
        self.axes.plot(range(split_index, len(data)), prediction_data, color='blue', label='Prediction')
        # 添加红色虚线作为分割线
        self.axes.axvline(x=split_index, color='red', linestyle='--')  
        #, label='Split Line

        # 设置X轴标签为右下，Y轴标签为左上
        self.axes.set_xlabel('Time', labelpad=15)  # 设置X轴标签，并设置距离轴的距离
        self.axes.xaxis.set_label_coords(1.05, -0.04)  # 将X轴标签位置设置到右下 (x=1.0表示最右，y=-0.1表示稍微偏下)

        self.axes.set_ylabel(unit, labelpad=15)  # 设置Y轴标签，并设置距离轴的距离
        self.axes.yaxis.set_label_coords(-0.08, 1.01)  # 将Y轴标签位置设置到左上 (x=-0.1表示稍微偏左，y=1.02表示在上方)
        self.axes.yaxis.label.set_rotation(0)  # 将Y轴标签旋转为水平显示
        # 添加标题和图例
        self.axes.set_title(title)
        self.axes.legend(loc='best')

        # 重新绘制图形
        self.draw()
# -----------------------------------------------------------------------------------------------
#  #QT界面应用
# -----------------------------------------------------------------------------------------------
class VideoApp(QWidget):
    global my_frame
    def __init__(self, user_data,interval=200):
        super().__init__()
        # 定义图片路径
        self.image_path = '/home/pi/ai_kit/FISHES-IN-THE-WILD/images/DSCN2382_C.jpg'  
        self.airunning = False
        self.running = True
        self.voicerunning = False
        self.current_image_index = 0
        self.data_path=[
            '/home/pi/temp/dc/data/resdata.csv',
            '/home/pi/temp/dc/data/resdata.csv',
            '/home/pi/temp/dc/data/resdata.csv',
            '/home/pi/temp/dc/data/resdata.csv',
            '/home/pi/temp/dc/data/resdata.csv',
            '/home/pi/temp/dc/data/resdata.csv',
            '/home/pi/temp/dc/data/resdata.csv'
        ]
        # 设置窗口布局
        self.init_ui()
        # 连接信号和槽
        user_data.frame_ready.connect(self.update_frame)
        self.update_data()
        # 设置定时器，用于实时更新图片
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.load_and_plot_data)
        self.timer.start(interval)  # 每隔 interval 毫秒更新一次图片        

    def init_ui(self):
        self.setWindowTitle('视频检测界面') # 设置窗口标题
        self.resize(1920,1080) # 窗口的大小
        #self.move(0, 0)# 将窗口设置在屏幕的左上角
        center_pointer = QDesktopWidget().availableGeometry().center()
        x = center_pointer.x()
        y = center_pointer.y()
        self.move(x, y)
        # 创建视频显示标签
        self.video_label = QLabel(self)
        self.video_label.setFixedSize(640, 480)
        # self.image_label = QLabel(self)
        # self.image_label.setFixedSize(320, 240)

        # 初始化五个 PlotCanvas 用于显示折线图
        self.canvas1 = PlotCanvas(self, width=3.2, height=3.2)
        self.canvas2 = PlotCanvas(self, width=3.2, height=2.4)
        self.canvas3 = PlotCanvas(self, width=3.2, height=2.4)
        self.canvas4 = PlotCanvas(self, width=3.2, height=2.4)
        self.canvas5 = PlotCanvas(self, width=3.2, height=2.4)
        self.canvas6 = PlotCanvas(self, width=3.2, height=2.4)

        # 创建一个QLabel用于显示文本
        self.text_label = QLabel("AI对话", self)
        self.text_label.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.text_label.setFixedSize(640, 480)
        self.text_label.setWordWrap(True)
        self.text_label.setStyleSheet("""
            QLabel {
                color: blue;               /* 设置文本颜色为蓝色 */
                border: 1px solid black;   /* 设置边框颜色为黑色 */
                padding: 5px;              /* 添加一些内边距 */
                background-color: yellow;
            }
        """)

        # 设置样式表
        label_style = """
            color: blue;                /* 文字颜色为蓝色 */
            background-color: yellow;   /* 背景颜色为黄色 */
            border: 2px solid black;    /* 黑色边框，宽度为2像素 */
            padding: 5px;               /* 内边距，确保文字与边框之间有些空间 */
        """
        # 定义标签并应用样式
        self.T_label = QLabel(f"Temperature: {deal_data.T}­°C", self)
        self.T_label.setStyleSheet(label_style)
        self.H_label = QLabel(f"Humidity: {deal_data.H}%", self)
        self.H_label.setStyleSheet(label_style)
        self.PA_label = QLabel(f"Atmospheric pressure: {deal_data.PA}pa", self)
        self.PA_label.setStyleSheet(label_style)
        self.A_label = QLabel(f"Altitude: {deal_data.A}m", self)
        self.A_label.setStyleSheet(label_style)
        self.L_label = QLabel(f"Light intensity: {deal_data.L}lux", self)
        self.L_label.setStyleSheet(label_style)
        self.watertemp_label = QLabel(f"Water Temperature: {deal_data.watertemp}­°C", self)
        self.watertemp_label.setStyleSheet(label_style)
        self.TDS_Value_label = QLabel(f"TDS Value: {deal_data.TDS_Value}ppm", self)
        self.TDS_Value_label.setStyleSheet(label_style)
        self.PH_Value_label = QLabel(f"PH Value: {deal_data.PH_Value}", self)
        self.PH_Value_label.setStyleSheet(label_style)
        self.ORP_Value_label = QLabel(f"ORP Value: {deal_data.ORP_Value}mv", self)
        self.ORP_Value_label.setStyleSheet(label_style)
        self.TU_Value_label = QLabel(f"Turbidity: {deal_data.TU_Value}NtU", self)
        self.TU_Value_label.setStyleSheet(label_style)
        self.waterlevel_label = QLabel(f"Water Level: {deal_data.waterlevel}", self)
        self.waterlevel_label.setStyleSheet(label_style)

        # 创建开始和停止按钮
        # 按钮样式表
        button_style = """
            background-color: blue;   /* 按钮背景颜色为蓝色 */
            color: white;             /* 按钮文字颜色为白色 */
            font-size: 18px;          /* 按钮文字大小 */
            border: 2px solid black;  /* 按钮边框为黑色，宽度为2像素 */
            padding: 10px 20px;       /* 内边距，确保按钮变大 */
        """

        # 定义并设置按钮样式
        self.start_button = QPushButton('开始', self)
        self.start_button.setStyleSheet(button_style)
        self.start_button.setFixedSize(150, 50)  # 设置按钮大小为150x50

        self.stop_button = QPushButton('停止', self)
        self.stop_button.setStyleSheet(button_style)
        self.stop_button.setFixedSize(150, 50)  # 设置按钮大小为150x50

        self.ai_start_button = QPushButton('询问AI', self)
        self.ai_start_button.setStyleSheet(button_style)
        self.ai_start_button.setFixedSize(150, 50)  # 设置按钮大小为150x50

        self.voice_start_button = QPushButton('语音播放', self)
        self.voice_start_button.setStyleSheet(button_style)
        self.voice_start_button.setFixedSize(150, 50)  # 设置按钮大小为150x50

        # 绑定按钮点击事件
        self.start_button.clicked.connect(self.start_detection)
        self.stop_button.clicked.connect(self.stop_detection)
        self.voice_start_button.clicked.connect(self.voice_start_detection)
        self.ai_start_button.clicked.connect(self.ai_start_detection)
        # 创建一个垂直布局来容纳所有的数据显示标签
        data_layout = QVBoxLayout()
        data_layout.addWidget(self.T_label)
        data_layout.addWidget(self.H_label)
        data_layout.addWidget(self.PA_label)
        data_layout.addWidget(self.A_label)
        data_layout.addWidget(self.L_label)
        data_layout.addWidget(self.TDS_Value_label)
        data_layout.addWidget(self.PH_Value_label)
        data_layout.addWidget(self.ORP_Value_label)
        data_layout.addWidget(self.TU_Value_label)
        data_layout.addWidget(self.waterlevel_label)
        data_layout.addWidget(self.watertemp_label)
        # -----创建第1个组，添加多个组件-----
        hobby_box = QGroupBox("水下监控与识别") # hobby 主要是保证他们是一个组。
        v_layout = QHBoxLayout()# v_layout 保证三个爱好是垂直摆
        v_layout.addWidget(self.video_label)
        v_layout.addLayout(data_layout)
        v_layout.addWidget(self.text_label)        
        v_layout.addWidget(self.canvas6)
        hobby_box.setLayout(v_layout)        # 把v_layout添加到hobby_box中
        # 创建分组框并布局
        ihobby_box = QGroupBox("数据与预测")
        iv_layout = QHBoxLayout()

        iv_layout.addWidget(self.canvas1)
        iv_layout.addWidget(self.canvas2)
        iv_layout.addWidget(self.canvas3)
        iv_layout.addWidget(self.canvas4)
        iv_layout.addWidget(self.canvas5)

        
        ihobby_box.setLayout(iv_layout)        # 把v_layout添加到hobby_box中

                # -----创建第2个组，添加多个组件-----
        # 性别组
        gender_box = QGroupBox("按键")
        # 性别容器
        h_layout = QHBoxLayout()
        # 性别选项
        # 追加到性别容器中
        h_layout.addWidget(self.start_button)
        h_layout.addWidget(self.stop_button)
        h_layout.addWidget(self.ai_start_button)
        h_layout.addWidget(self.voice_start_button)
        # 添加到 box中
        gender_box.setLayout(h_layout)

       # 最外层的垂直布局，包含两部分：爱好和性别
        container = QVBoxLayout()
        container.addWidget(hobby_box)
        container.addWidget(ihobby_box)
        container.addWidget(gender_box)

        # 设置窗口显示的内容是最外层容器
        # self.setLayout(container)
        # self.show()
        first_page = QWidget()
        first_page.setLayout(container)

        # 添加第一个界面到 stacked_widget
        self.stacked_widget.addWidget(first_page)

        # 显示 stacked_widget
        layout = QVBoxLayout(self)
        layout.addWidget(self.stacked_widget)
        self.setLayout(layout)
    def switch_to_new_ui(self):
        # 创建第二个界面
        new_ui = QWidget()
        new_ui.setStyleSheet("background-color: lightblue;")
        layout = QVBoxLayout(new_ui)

        new_label = QLabel('这是新的界面', new_ui)
        new_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(new_label)

        back_button = QPushButton('返回', new_ui)
        back_button.clicked.connect(self.switch_back_to_main_ui)
        layout.addWidget(back_button)


        container = QVBoxLayout()
        container.addWidget(hobby_box)
        container.addWidget(ihobby_box)
        container.addWidget(gender_box)
        
        # 添加新界面到 stacked_widget
        self.stacked_widget.addWidget(new_ui)

        # 切换到新界面
        self.stacked_widget.setCurrentWidget(new_ui)
    def start_detection(self):
        if not self.running:
            self.running = True

    def stop_detection(self):
        if self.running:
            self.running = False
    def ai_start_detection(self):
        self.ai_start_button.setText("语音识别中")
        self.update_conversation()

    def voice_start_detection(self):
        if self.voicerunning:
            self.voicerunning = True

    def update_conversation(self):
        # 调用语音识别，立即显示结果
        result = "你好"  # 示例语音识别结果，实际使用时替换为 myaila.speech_to_text()
        user_text = f"user：“{result}”"
        # 获取当前对话框的文本并追加用户的语音识别结果
        current_text = self.text_label.text()
        new_conversation = f"{current_text}\n{user_text}"
        self.text_label.setText(new_conversation)
        # 启动线程，异步获取 AI 响应
        threading.Thread(target=self.get_ai_response, args=(result,)).start()
        
    def get_ai_response(self, user_input):
        # 调用 AI 生成响应
        self.ai_start_button.setText("AI思考中")
        ai_text = myaila.getai(user_input)
        # 在AI生成后，更新UI需要放回主线程
        self.update_ai_response(ai_text)

    def update_ai_response(self, ai_text):
        # 获取当前对话框的文本并追加 AI 响应
        current_text = self.text_label.text()
        new_conversation = f"{current_text}\nAI：“{ai_text}”"
        
        # 更新界面
        self.text_label.setText(new_conversation)
        self.ai_start_button.setText("询问AI")
      
    def update_frame(self, frame):
        if self.running:
            # 转换为Qt可用的格式并显示
            height, width, channel = frame.shape
            bytesPerLine = 3 * width
            qImg = QImage(frame.data, width, height, bytesPerLine, QImage.Format_RGB888)
            pixmap = QPixmap.fromImage(qImg)
            self.video_label.setPixmap(pixmap)

    def update_data(self):
        # 使用定时器或者循环持续更新数据
        self.T_label.setText(f"Temperature: {deal_data.T}­°C")
        self.H_label.setText(f"Humidity: {deal_data.H}%")
        self.PA_label.setText(f"Air pressure: {deal_data.PA}pa")
        self.A_label.setText(f"Altitude: {deal_data.A}m")
        self.L_label.setText(f"LLight intensity: {deal_data.L}lux")
        self.watertemp_label.setText(f"Water Temperature: {deal_data.watertemp}­°C")
        self.TDS_Value_label.setText(f"TDS Value: {deal_data.TDS_Value}ppm")
        self.PH_Value_label.setText(f"PH Value: {deal_data.PH_Value}")
        self.ORP_Value_label.setText(f"ORP Value: {deal_data.ORP_Value}mv")
        self.TU_Value_label.setText(f"Turbidity: {deal_data.TU_Value}NTU")
        self.waterlevel_label.setText(f"Water Level: {deal_data.waterlevel}m")
    # def update_images(self):
    #     if self.running:
    #         self.image_label.setPixmap(QPixmap(self.image_path))

    def load_and_plot_data(self):
        combined_data = []  # 初始化存储所有combined_data的列表
        split_inde = []  # 初始化存储所有split_index的列表
        
        for i in range(6):
            # 将结果追加到列表中
            combined_data_item, split_index_item = self.deal_combined_data(self.data_path[i])
            combined_data.append(combined_data_item)  # 将combined_data_item添加到列表
            split_inde.append(split_index_item)  # 将split_index_item添加到列表

        # 使用 plot 方法绘制图形，前70%为真实数据，后30%为预测数据
        self.canvas1.plot(combined_data[0], split_inde[0], 'TDS Value','ppm')
        self.canvas2.plot(combined_data[1], split_inde[1], 'PH Value','ph')
        self.canvas3.plot(combined_data[2], split_inde[2], 'ORP Value','mv')
        self.canvas4.plot(combined_data[3], split_inde[3], 'Turbidity','NTU')
        self.canvas5.plot(combined_data[4], split_inde[4], 'Water Level','m')
        self.canvas6.plot(combined_data[5], split_inde[5], 'Water Temperature','°C')

    def deal_combined_data(self, datapath):
        # 读取 CSV 文件数据
        data = pd.read_csv(datapath)
        
        # 获取 'Real' 和 'Prediction' 列的数据
        real_data = data['Real'].values
        prediction_data = data['Prediction'].values
        
        # 将 'Real' 和 'Prediction' 数据合并为一个数组
        combined_data = real_data.copy()
        combined_data[-len(prediction_data):] = prediction_data  # 替换后面部分为预测数据
        
        # 计算分割点，前70%是训练数据
        split_index = int(len(combined_data) * 0.7)
        
        return combined_data, split_index


# -----------------------------------------------------------------------------------------------
# 用户定义的 GStreamer 应用
# -----------------------------------------------------------------------------------------------
def run_gstreamer_app(args, user_data):
    app = GStreamerDetectionApp(args, user_data)
    app.run()
    loop = GLib.MainLoop()
    loop.run()

# -----------------------------------------------------------------------------------------------
# 主程序
# -----------------------------------------------------------------------------------------------
if __name__ == "__main__":
    user_data = user_app_callback_class()
    parser = get_default_parser()
    parser.add_argument('--labels-json', type=str, help='标签配置文件路径')
    parser.add_argument('--hef-path', type=str, help='HEF 文件路径')
    parser.add_argument('--network', type=str, default='yolov8s', help='网络类型（默认为yolov8s）')
    args = parser.parse_args()

    # # # # 启动 GStreamer 应用程序线程
    gstreamer_thread = threading.Thread(target=run_gstreamer_app, args=(args, user_data))
    gstreamer_thread.start()

    # uart_tark_thread = threading.Thread(target=deal_data.uart_tark)
    # uart_tark_thread.start()

    # 启动 Qt 应用程序
    app = QApplication(sys.argv)
    video_app = VideoApp(user_data)
    video_app.show()
    sys.exit(app.exec_())
