import serial
import re
import csv
import os
from datetime import datetime

data_directory = '../data'
if not os.path.exists(data_directory):
    os.makedirs(data_directory)

csv_file = os.path.join(data_directory, 'data.csv')

if not os.path.exists(csv_file):
    with open(csv_file, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Timestamp", "Temperature", "Humidity", "Pressure", "Altitude", "Light", "Water Temp", "TDS", "PH", "ORP", "Turbidity", "Water Level"])

def create_individual_csv(file_name, header):
    file_path = os.path.join(data_directory, file_name)
    if not os.path.exists(file_path):
        with open(file_path, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["Timestamp", header])

create_individual_csv('Temperature.csv', 'Temperature')
create_individual_csv('Humidity.csv', 'Humidity')
create_individual_csv('Pressure.csv', 'Pressure')
create_individual_csv('Altitude.csv', 'Altitude')
create_individual_csv('Light.csv', 'Light')
create_individual_csv('Water_Temperature.csv', 'Water Temperature')
create_individual_csv('TDS.csv', 'TDS')
create_individual_csv('PH.csv', 'PH')
create_individual_csv('ORP.csv', 'ORP')
create_individual_csv('Turbidity.csv', 'Turbidity')
create_individual_csv('Water_Level.csv', 'Water Level')

def write_data_filer(T, H, PA, A, L, watertemp, TDS_Value, PH_Value, ORP_Value, TU_Value, waterlevel):
    timestamp = datetime.now().strftime("%H:%M:%S")
    
    # Writing to the main CSV file
    with open(csv_file, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, T, H, PA, A, L, watertemp, TDS_Value, PH_Value, ORP_Value, TU_Value, waterlevel])
    
    # Writing to individual CSV files with timestamp
    with open(os.path.join(data_directory, 'Temperature.csv'), mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, T])

    with open(os.path.join(data_directory, 'Humidity.csv'), mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, H])

    with open(os.path.join(data_directory, 'Pressure.csv'), mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, PA])

    with open(os.path.join(data_directory, 'Altitude.csv'), mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, A])

    with open(os.path.join(data_directory, 'Light.csv'), mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, L])

    with open(os.path.join(data_directory, 'Water_Temperature.csv'), mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, watertemp])

    with open(os.path.join(data_directory, 'TDS.csv'), mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, TDS_Value])

    with open(os.path.join(data_directory, 'PH.csv'), mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, PH_Value])

    with open(os.path.join(data_directory, 'ORP.csv'), mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, ORP_Value])

    with open(os.path.join(data_directory, 'Turbidity.csv'), mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, TU_Value])

    with open(os.path.join(data_directory, 'Water_Level.csv'), mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, waterlevel])
