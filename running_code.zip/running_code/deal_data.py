import serial
import re
import Save_data
import time
import onenet
from datetime import datetime

ser = serial.Serial(port='/dev/ttyAMA2', baudrate=115200)
MAX_BUFFER_SIZE = 256
rx_buffer = []
rx_index = 0  # 初始化rx_index

# 初始化所有传感器值
T = H = PA = A = L = watertemp = TDS_Value = PH_Value = ORP_Value = TU_Value = waterlevel = fx=0.0

# def Receiving_and_parsing_data(rx_buffer):
#     global T, H, PA, A, L, watertemp, TDS_Value, PH_Value, ORP_Value, TU_Value, waterlevel
#     try:
#         received_str = ''.join(rx_buffer)
#         print(f"Received Data: {received_str}")  # Debug line to see raw data
        
#         # 调整正则表达式以适应数据格式
#         pattern = r"T:(-?\d+\.?\d*);H=(-?\d+\.?\d*);P:(-?\d+\.?\d*);A:(-?\d+\.?\d*);L:(-?\d+\.?\d*);WT:(-?\d+\.?\d*);TDS:(-?\d+\.?\d*);PH:(-?\d+\.?\d*);ORP:(-?\d+\.?\d*);TU:(-?\d+\.?\d*);WL:(-?\d+\.?\d*);"
        
#         match = re.search(pattern, received_str)
        
#         if match:
#             T, H, PA, A, L, watertemp, TDS_Value, PH_Value, ORP_Value, TU_Value, waterlevel = map(float, match.groups())
#             if any(value == 0 for value in [T, H, PA, A, L, watertemp, TDS_Value, PH_Value, ORP_Value, TU_Value, waterlevel]):
#                 print("Received data contains zero value. Discarding this entry.")
#                 return
#             Save_data.write_data_filer(T, H, PA, A, L, watertemp, TDS_Value, PH_Value, ORP_Value, TU_Value, waterlevel)
#         else:
#             print("error_uart_1")  # 这里可以添加更多信息，例如接收到的数据
            
#     except Exception as e:
#         print(f"error_uart: {e}")
def Receiving_and_parsing_data(rx_buffer):
    global T, H, PA, A, L, watertemp, TDS_Value, PH_Value, ORP_Value, TU_Value, waterlevel, fx
    try:
        received_str = ''.join(rx_buffer)
        print(f"Received Data: {received_str}")  # 调试输出

        # 优先解析 fx（F:）值
        fx_match = re.search(r"F:(\d+);", received_str)
        if fx_match:
            fx = int(fx_match.group(1))
            print(f"fx value received: {fx}")
            onenet.send_data_to_onenet("feeding", fx)

        # 正则表达式解析传感器数据
        pattern = (
            r"T:(-?\d+\.?\d*);H=(-?\d+\.?\d*);P:(-?\d+\.?\d*);A:(-?\d+\.?\d*);L:(-?\d+\.?\d*);"
            r"WT:(-?\d+\.?\d*);TDS:(-?\d+\.?\d*);PH:(-?\d+\.?\d*);ORP:(-?\d+\.?\d*);"
            r"TU:(-?\d+\.?\d*);WL:(-?\d+\.?\d*);"
        )

        match = re.search(pattern, received_str)
        if match:
            T, H, PA, A, L, watertemp, TDS_Value, PH_Value, ORP_Value, TU_Value, waterlevel = map(float, match.groups())

            if any(value == 0 for value in [T, H, PA, A, L, watertemp, TDS_Value, PH_Value, ORP_Value, TU_Value, waterlevel]):
                print("Received data contains zero value. Discarding this entry.")
                return

            Save_data.write_data_filer(T, H, PA, A, L, watertemp, TDS_Value, PH_Value, ORP_Value, TU_Value, waterlevel)
        else:
            print("error_uart_1: failed to match sensor data format")

    except Exception as e:
        print(f"error_uart: {e}")


# def send_current_time():
#     current_time = time.strftime("time:%Y-%m-%d-%H-%M-%d;", time.localtime(),feeding)#
#     ser.write(f"{current_time}\n".encode('utf-8'))
def send_current_time(feeding_value):
    current_time_str = time.strftime("time:%Y-%m-%d-%H-%M", time.localtime())
    full_data = f"{current_time_str}-{feeding_value};"
    ser.write(full_data.encode('utf-8'))


onenet_flag = 0
all_time=0
# 分阶段打包数据，结构清晰易维护
def get_send_data_groups():
    return [
        [("temp", T), ("humi", H), ("atmos", PA), ("alt", A)],
        [("light", L), ("watertemperature", watertemp), ("tds", TDS_Value), ("ph", PH_Value)],
        [("orp", ORP_Value), ("lux", TU_Value), ("waterhight", waterlevel),("ledbtn",all_time)]
    ]

def onenet_task(): 
    global onenet_flag, all_time
    time_start=time.time()
    while True:
        all_time = round((time.time() - time_start) / 60, 2)  # 运行分钟数
        data_groups = get_send_data_groups()
        if 0 <= onenet_flag < len(data_groups):
            for key, value in data_groups[onenet_flag]:
                onenet.send_data_to_onenet(key, value)
        onenet_flag = (onenet_flag + 1) % len(data_groups)
        onenet.fetch_data_from_onenet()
def parse_timex(timex):
    try:
        int_part = int(timex)
        dec_part = round((timex - int_part) * 10000)  # 获取小数部分并转换成4位整数

        # 解析整数部分为 time1 和 time2
        str_int = str(int_part).zfill(8)  # 保证整数部分是8位，不足前补0
        h1, m1 = str_int[0:2], str_int[2:4]
        h2, m2 = str_int[4:6], str_int[6:8]

        # 解析小数部分为 time3
        str_dec = str(dec_part).zfill(4)  # 小数部分4位，不足补0
        h3, m3 = str_dec[0:2], str_dec[2:4]

        time1 = f"{h1}:{m1}"
        time2 = f"{h2}:{m2}"
        time3 = f"{h3}:{m3}"

        return time1, time2, time3
    except Exception as e:
        print(f"[parse_timex] Error parsing timex: {e}")
        return "00:00", "00:00", "00:00"

 

def uart_tark():
    global rx_index, MAX_BUFFER_SIZE, rx_buffer
    begin_time = time.time()
    ci = 0
    while True:
        if time.time() - begin_time >= 1:
            time1,time2,time3=parse_timex(onenet.timex)
            now = datetime.now().strftime("%H:%M")  # 当前时间格式为 "HH:MM"
            fs=onenet.feeding
            if now in [time1, time2, time3] and datetime.now().second  < 3:
                 fs=fs%1000+3000
            send_current_time(fs)
            print(f"timex: {onenet.timex}, time1: {time1}, time2: {time2}, time3: {time3}, fs: {fs}")
            begin_time = time.time()
            # print(f"ci:{ci} Temperature: {T},Humidity: {H}, Pressure: {PA}, Altitude: {A}, Light: {L}, Water Temp: {watertemp}, TDS: {TDS_Value}, PH: {PH_Value}, ORP: {ORP_Value}, Turbidity: {TU_Value}, Water Level: {waterlevel},feeding :{onenet.feeding}")
        if ser.in_waiting > 0:
            received_data = ser.read().decode('utf-8')
            if rx_index == 0 and received_data != 'T':
                continue
            rx_buffer.append(received_data)
            rx_index += 1
            
            # 检查数据结束符
            if rx_index >= MAX_BUFFER_SIZE or received_data == '\n':
                Receiving_and_parsing_data(rx_buffer)
                rx_buffer = []
                rx_index = 0  # 重置 rx_index
            # 这里可以选择是否清理缓冲区
            elif len(rx_buffer) > MAX_BUFFER_SIZE:
                print("Buffer overflow, clearing buffer")
                rx_buffer = []
                rx_index = 0  # Reset index if overflow

# if __name__ == "__main__":
#     uart_tark()
