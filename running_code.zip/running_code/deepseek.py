import requests
import os

# 配置API
url = "https://api.siliconflow.cn/v1/chat/completions"
headers = {
    "Authorization": "Bearer sk-rjjuddjkobpcvvduadvlgclburptmyvlmkwrfvylsqgetxcv",  # 替换为你的实际 API 密钥
    "Content-Type": "application/json"
}

def get_assistant_response(user_input):
    print("AI思考中...")
    """发送请求并获取助手回复"""
    payload = {
        "model": "Qwen/QwQ-32B",
        "messages": [
            {
                "role": "user",
                "content": user_input
            }
        ],
        "stream": False,
        "max_tokens": 512,
        "temperature": 0.7,
        "top_p": 0.7,
        "top_k": 50,
        "frequency_penalty": 0.5,
        "n": 1,
        "stop": "#",
        "tools": [
            {
                "function": {
                    "strict": False,
                    "name": "小智",
                    "description": "你是一个水产养殖的专家"
                },
                "type": "function"
            }
        ]
    }

    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        response_data = response.json()

        # 提取助手的回答内容
        assistant_content = response_data['choices'][0]['message']['content']

        # 清理响应内容
        target_marker = "\n</think>\n\n"
        if target_marker in assistant_content:
            return assistant_content.split(target_marker)[-1].strip()
        return assistant_content.strip()

    except requests.exceptions.RequestException as e:
        return f"请求出错: {e}"
    except (KeyError, IndexError) as e:
        return f"解析响应出错: {e}"

#if __name__ == "__main__":
def trycode():
    print("欢迎使用水产养殖专家助手(输入'退出'结束对话)")
    while True:
        user_input = input("你: ")
        if user_input.lower() in ['退出', 'exit', 'quit']:
            print("对话结束，再见！")
            break

        response = get_assistant_response(user_input)
        print("\n助手:", response, "\n")




 