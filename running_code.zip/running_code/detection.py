#!/usr/bin/python3
# -*- encoding: utf-8 -*-
import threading
import gi
gi.require_version('Gst', '1.0')
from gi.repository import Gst, GLib
import os
import argparse
import numpy as np
import setproctitle
import cv2
import hailo
import threading
from hailo_rpi_common import (
    get_default_parser,
    QUEUE,
    get_caps_from_pad,
    get_numpy_from_buffer,
    GStreamerApp,
    app_callback_class,
)
import sys

from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import pandas as pd
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.ticker import MaxNLocator

import deal_data
import lstm
import myaila


my_frame = None  # 全局变量来存储帧
# -----------------------------------------------------------------------------------------------
# 用户自定义类，用于回调函数中
# -----------------------------------------------------------------------------------------------
class user_app_callback_class(QObject, app_callback_class):
    frame_ready = pyqtSignal(np.ndarray)  # 定义一个信号，传递处理好的帧
    def __init__(self):
        super().__init__()
        self.new_variable = 42  # 定义一个新的变量示例
        self.use_frame = True      # 添加用于存储当前帧的变量

    def new_function(self):  # 定义一个新的方法示例
        return "生命的意义是: "

# -----------------------------------------------------------------------------------------------
# 用户自定义的回调函数
# -----------------------------------------------------------------------------------------------
def app_callback(pad, info, user_data):
    global my_frame
    buffer = info.get_buffer()
    if buffer is None:
        return Gst.PadProbeReturn.OK

    user_data.increment()
    string_to_print = f"帧计数: {user_data.get_count()}\n"

    format, width, height = get_caps_from_pad(pad)
    frame = None
    # print(f"user_data.use_frame: {user_data.use_frame}")
    if user_data.use_frame:
        frame = get_numpy_from_buffer(buffer, format, width, height)

    # 获取 ROI 并检测物体
    roi = hailo.get_roi_from_buffer(buffer)
    detections = roi.get_objects_typed(hailo.HAILO_DETECTION)

    detection_count = 0
    for detection in detections:
        label = detection.get_label()
        bbox = detection.get_bbox()  # 获取边界框
        confidence = detection.get_confidence()
        # 如果检测到 "person"，计数并输出
        if label == "fish":
            string_to_print += f"检测到: {label} 置信度: {confidence:.2f}\n"
            detection_count += 1
        # 画出识别框
        xmin, ymin, width, height = int(bbox.xmin() * frame.shape[1]), int(bbox.ymin() * frame.shape[0]), int(bbox.width() * frame.shape[1]), int(bbox.height() * frame.shape[0])
        cv2.rectangle(frame, (xmin, ymin), (xmin + width, ymin + height), (0, 255, 0), 2)
        cv2.putText(frame, f"{label} {confidence:.2f}", (xmin, ymin - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (36,255,12), 1)

    if user_data.use_frame:
        cv2.putText(frame, f"Num: {detection_count}", (20, 180), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255, 255), 1)
        #cv2.putText(frame, f"{user_data.new_function()} {user_data.new_variable}", (100, 260), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        user_data.frame_ready.emit(frame)
        frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        my_frame = frame
    
    # print(string_to_print)
    return Gst.PadProbeReturn.OK

# -----------------------------------------------------------------------------------------------
# 用户定义的 Gstreamer 应用
# -----------------------------------------------------------------------------------------------
class GStreamerDetectionApp(GStreamerApp):
    def __init__(self, args, user_data):
        super().__init__(args, user_data)
        self.batch_size = 2
        self.network_width = 640
        self.network_height = 640
        self.network_format = "RGB"
        nms_score_threshold = 0.3
        nms_iou_threshold = 0.45

        new_postprocess_path = os.path.join(self.current_path, '../resources/libyolo_hailortpp_post.so')
        if os.path.exists(new_postprocess_path):
            self.default_postprocess_so = new_postprocess_path
        else:
            self.default_postprocess_so = os.path.join(self.postprocess_dir, 'libyolo_hailortpp_post.so')

        if args.hef_path is not None:
            self.hef_path = args.hef_path
        elif args.network == "yolov6n":
            self.hef_path = os.path.join(self.current_path, '../resources/yolov6n.hef')
        elif args.network == "yolov8s":
            self.hef_path = os.path.join(self.current_path, '../resources/yolov8s_h8l.hef')
        elif args.network == "yolox_s_leaky":
            self.hef_path = os.path.join(self.current_path, '../resources/yolox_s_leaky_h8l_mz.hef')
        else:
            assert False, "无效的网络类型"

        if args.labels_json is not None:
            self.labels_config = f' config-path={args.labels_json} '
        else:
            self.labels_config = ''

        self.app_callback = app_callback

        self.thresholds_str = (
            f"nms-score-threshold={nms_score_threshold} "
            f"nms-iou-threshold={nms_iou_threshold} "
            f"output-format-type=HAILO_FORMAT_TYPE_FLOAT32"
        )

        setproctitle.setproctitle("Hailo Detection App")
        self.create_pipeline()

    def get_pipeline_string(self):
        if self.source_type == "rpi":
            source_element = (
                "libcamerasrc name=src_0 ! "
                f"video/x-raw, format={self.network_format}, width=1536, height=864 ! "
                + QUEUE("queue_src_scale")
                + "videoscale ! "
                f"video/x-raw, format={self.network_format}, width={self.network_width}, height={self.network_height}, framerate=30/1 ! "
            )
        elif self.source_type == "usb":
            source_element = (
                f"v4l2src device={self.video_source} name=src_0 ! "
                "video/x-raw, width=640, height=480, framerate=30/1 ! "
            )
        else:
            source_element = (
                f"filesrc location=\"{self.video_source}\" name=src_0 ! "
                + QUEUE("queue_dec264")
                + " qtdemux ! h264parse ! avdec_h264 max-threads=2 ! "
                " video/x-raw, format=I420 ! "
            )
        source_element += QUEUE("queue_scale")
        source_element += "videoscale n-threads=2 ! "
        source_element += QUEUE("queue_src_convert")
        source_element += "videoconvert n-threads=3 name=src_convert qos=false ! "
        source_element += f"video/x-raw, format={self.network_format}, width={self.network_width}, height={self.network_height}, pixel-aspect-ratio=1/1 ! "

        pipeline_string = (
            "hailomuxer name=hmux "
            + source_element
            + "tee name=t ! "
            + QUEUE("bypass_queue", max_size_buffers=20)
            + "hmux.sink_0 "
            + "t. ! "
            + QUEUE("queue_hailonet")
            + "videoconvert n-threads=3 ! "
            f"hailonet hef-path={self.hef_path} batch-size={self.batch_size} {self.thresholds_str} force-writable=true ! "
            + QUEUE("queue_hailofilter")
            + f"hailofilter so-path={self.default_postprocess_so} {self.labels_config} qos=false ! "
            + QUEUE("queue_hmuc")
            + "hmux.sink_1 "
            + "hmux. ! "
            + QUEUE("queue_hailo_python")
            + QUEUE("queue_user_callback")
            + "identity name=identity_callback ! "
            + QUEUE("queue_hailooverlay")
            + "hailooverlay ! "
            + QUEUE("queue_videoconvert")
            + "videoconvert n-threads=3 qos=false ! "
            + QUEUE("queue_hailo_display")
            #+ f"fpsdisplaysink video-sink={self.video_sink} name=hailo_display sync={self.sync} text-overlay={self.options_menu.show_fps} signal-fps-measurements=true " 
            + "fakesink name=output_sink sync=true"
        )
        print(pipeline_string)
        return pipeline_string
class PlotCanvas(FigureCanvas):

    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)  # 创建绘图区域
        super().__init__(fig)

    def plot(self, data, split_index, timestamps, title, unit):
        # 清除之前的绘图
        self.axes.clear()

        # 前70%的数据作为Real（绿色）
        real_data = data[:split_index]
        self.axes.plot(timestamps[:split_index], real_data, color='green', label='Real')

        # 后30%的数据作为Prediction（蓝色）
        prediction_data = data[split_index:]
        self.axes.plot(timestamps[split_index:], prediction_data, color='blue', label='Prediction')

        # 添加红色虚线作为分割线
        self.axes.axvline(x=timestamps[split_index], color='red', linestyle='--')  # 使用时间戳作为分割线位置

        # 设置X轴标签为右下
        self.axes.set_xlabel('Timestamp', labelpad=15)  # 设置X轴标签，并设置距离轴的距离
        self.axes.xaxis.set_label_coords(1.05, -0.04)  # 将X轴标签位置设置到右下
        self.axes.set_xticks(range(split_index))
        self.axes.set_xticklabels(timestamps[:split_index], rotation=15, ha='right', fontsize=5)
        self.axes.xaxis.set_major_locator(MaxNLocator(integer=True, nbins=8))  # 最多显示10个刻度

        # 设置Y轴标签为左上
        self.axes.set_ylabel(unit, labelpad=15)  # 设置Y轴标签，并设置距离轴的距离
        self.axes.yaxis.set_label_coords(-0.08, 1.01)  # 将Y轴标签位置设置到左上
        self.axes.yaxis.label.set_rotation(0)  # 将Y轴标签旋转为水平显示

        # 设置y轴刻度标签的字体大小为7，并旋转15度
        self.axes.tick_params(axis='y', labelsize=7, rotation=15)

        # 添加标题和图例
        self.axes.set_title(title)
        self.axes.legend(loc='best')

        # 重新绘制图形
        self.draw()

# -----------------------------------------------------------------------------------------------
#  #QT界面应用
# -----------------------------------------------------------------------------------------------
class VideoApp(QWidget):
    global my_frame
    def __init__(self, user_data,interval=1000):
        super().__init__()
        # 定义图片路径
        self.image_path = '/home/pi/ai_kit/FISHES-IN-THE-WILD/images/DSCN2382_C.jpg'  
        self.lstm_running = 0
        self.running = False
        self.voicerunning = False
        self.current_image_index = 0
        self.ai_current_text="你好"
        self.voice_output_file="/home/pi/temp/dc/resources/aitext.wav"
        # 创建 QStackedWidget 来管理多个界面
        self.stacked_widget = QStackedWidget(self)
        # 设置窗口布局
        self.init_ui()
        # 连接信号和槽
        user_data.frame_ready.connect(self.update_frame)
        self.update_data()
        # 设置定时器，用于实时更新图片
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.load_and_plot_data)
        self.timer.start(interval)  # 每隔 interval 毫秒更新一次图片        

    def crea(self):
                # 创建视频显示标签
        self.video_label = QLabel(self)
        self.video_label.setFixedSize(426, 240)
        # # 创建一个QLabel用于显示文本
        # self.text_label = QLabel("AI对话", self)
        # self.text_label.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        # self.text_label.setFixedSize(320, 240)
        # self.text_label.setWordWrap(True)
        # self.text_label.setStyleSheet("""
        #     QLabel {
        #         color: blue;               /* 设置文本颜色为蓝色 */
        #         border: 1px solid black;   /* 设置边框颜色为黑色 */
        #         padding: 5px;              /* 添加一些内边距 */
        #         background-color: yellow;
        #     }
        # """)
        # 创建一个 QScrollArea 来包裹 QLabel
        self.scroll_area = QScrollArea(self)
        self.scroll_area.setFixedSize(320, 240)
        self.scroll_area.setWidgetResizable(True)  # 自动调整以适应内容

        # 创建 QLabel 用于显示文本
        self.text_label = QLabel("AI对话", self)
        self.text_label.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.text_label.setWordWrap(True)
        self.text_label.setStyleSheet("""
            QLabel {
                color: blue;               /* 设置文本颜色为蓝色 */
                border: 1px solid black;   /* 设置边框颜色为黑色 */
                padding: 5px;              /* 添加一些内边距 */
                background-color: yellow;
            }
        """)

        # 将 QLabel 放入 QScrollArea 中
        self.scroll_area.setWidget(self.text_label)

        # 设置样式表
        label_style = """
            color: blue;                /* 文字颜色为蓝色 */
            background-color: yellow;   /* 背景颜色为黄色 */
            border: 1px solid black;    /* 黑色边框，宽度为2像素 */
            padding: 2px;               /* 内边距，确保文字与边框之间有些空间 */
        """
        # 定义标签并应用样式
        self.T_label = QLabel(f"温度: {deal_data.T}­°C", self)
        self.T_label.setStyleSheet(label_style)
        self.H_label = QLabel(f"湿度: {deal_data.H}%", self)
        self.H_label.setStyleSheet(label_style)
        self.PA_label = QLabel(f"大气压: {deal_data.PA}pa", self)
        self.PA_label.setStyleSheet(label_style)
        self.A_label = QLabel(f"海拔: {deal_data.A}m", self)
        self.A_label.setStyleSheet(label_style)
        self.L_label = QLabel(f"光强: {deal_data.L}lux", self)
        self.L_label.setStyleSheet(label_style)
        self.watertemp_label = QLabel(f"水温: {deal_data.watertemp}­°C", self)
        self.watertemp_label.setStyleSheet(label_style)        
        self.waterlevel_label = QLabel(f"水位: {deal_data.waterlevel}", self)
        self.waterlevel_label.setStyleSheet(label_style)        
        self.TDS_Value_label = QLabel(f"TDSValue: {deal_data.TDS_Value}ppm", self)
        self.TDS_Value_label.setStyleSheet(label_style)
        self.PH_Value_label = QLabel(f"PHValue: {deal_data.PH_Value}", self)
        self.PH_Value_label.setStyleSheet(label_style)
        self.ORP_Value_label = QLabel(f"ORPValue: {deal_data.ORP_Value}mv", self)
        self.ORP_Value_label.setStyleSheet(label_style)
        self.TU_Value_label = QLabel(f"Turbidity: {deal_data.TU_Value}NtU", self)
        self.TU_Value_label.setStyleSheet(label_style)
        button_style = """
            background-color: blue;   /* 按钮背景颜色为蓝色 */
            color: white;             /* 按钮文字颜色为白色 */
            font-size: 9px;          /* 按钮文字大小 */
            border: 2px solid black;  /* 按钮边框为黑色，宽度为2像素 */
            padding: 5px 10px;       /* 内边距，确保按钮变大 */
        """
        # 定义并设置按钮样式
        self.start_button = QPushButton('开始', self)
        self.start_button.setStyleSheet(button_style)
        self.start_button.setFixedSize(100, 25)  # 设置按钮大小为150x50
        self.stop_button = QPushButton('预测', self)
        self.stop_button.setStyleSheet(button_style)
        self.stop_button.setFixedSize(100, 25)  # 设置按钮大小为150x50
        self.ai_start_button = QPushButton('询问AI', self)
        self.ai_start_button.setStyleSheet(button_style)
        self.ai_start_button.setFixedSize(100, 25)  # 设置按钮大小为150x50
        self.voice_start_button = QPushButton('语音播放', self)
        self.voice_start_button.setStyleSheet(button_style)
        self.voice_start_button.setFixedSize(100, 25)  # 设置按钮大小为150x50
        # 初始化五个 PlotCanvas 用于显示折线图
        self.canvas = [None] * 8
        for i in range(8):
            if i!=0 and i!=7:
                self.canvas[i] = PlotCanvas(self, width=3.2, height=2.8)
            if i==7:
                self.canvas[i] = PlotCanvas(self, width=8.0, height=3.3)

    def init_ui(self):
        self.setWindowTitle('视频检测界面') # 设置窗口标题
        self.resize(1024,600) # 窗口的大小
        #self.move(0, 0)# 将窗口设置在屏幕的左上角
        center_pointer = QDesktopWidget().availableGeometry().center()
        x = center_pointer.x()
        y = center_pointer.y()
        self.move(x, y)
        self.crea()
        # 绑定按钮点击事件
        self.start_button.clicked.connect(self.start_detection)
        self.stop_button.clicked.connect(self.stop_detection)
        self.voice_start_button.clicked.connect(self.voice_start_detection)
        self.ai_start_button.clicked.connect(self.ai_start_detection)
        # 创建一个垂直布局来容纳所有的数据显示标签
        data_layout = QVBoxLayout()
        data_layout.addWidget(self.T_label)
        data_layout.addWidget(self.H_label)
        data_layout.addWidget(self.PA_label)
        data_layout.addWidget(self.A_label)
        data_layout.addWidget(self.L_label)
        data_layout.addWidget(self.watertemp_label)
        data_layout.addWidget(self.waterlevel_label)
        data_layout.addWidget(self.TDS_Value_label)
        data_layout.addWidget(self.PH_Value_label)
        data_layout.addWidget(self.ORP_Value_label)
        data_layout.addWidget(self.TU_Value_label)
        
       

        # 创建布局以显示视频标签和AI助手标签
        i4v_layout = QHBoxLayout()
        i4v_layout.addWidget(self.video_label)
        i4v_layout.addWidget(self.scroll_area)

        # 布局与图表的结合
        i4v_widget = QWidget()
        i4v_widget.setLayout(i4v_layout)

        # 显示额外的图表布局
        i5v_layout = QHBoxLayout()
     
        i5v_layout.addWidget(self.canvas[7])

        # 创建按钮布局
        h_layout = QHBoxLayout()
        h_layout.addWidget(self.start_button)
        h_layout.addWidget(self.stop_button)
        h_layout.addWidget(self.ai_start_button)
        h_layout.addWidget(self.voice_start_button)

        # 结合按钮和图表布局
        h_widget = QWidget()
        h_widget.setLayout(h_layout)

        # 创建一个垂直布局，容纳所有的控件
        i6v_layout = QVBoxLayout()
        i6v_layout.addWidget(i4v_widget)  # 水下监控与识别 和 AI助手
        i6v_layout.addWidget(self.canvas[7])  # 图表
        i6v_layout.addWidget(h_widget)  # 按钮

        # 容器布局，容纳所有内容
        container = QHBoxLayout()
        container.addLayout(i6v_layout)  # 水下监控与识别、AI助手、图表、按钮
        container.addLayout(data_layout)  # 实时数据

        first_page = QWidget()
        first_page.setLayout(container)
        self.stacked_widget.addWidget(first_page)
        # 显示 stacked_widget
        layout = QVBoxLayout(self)
        layout.addWidget(self.stacked_widget)
        self.setLayout(layout)

    def switch_to_new_ui(self):
        # 创建第二个界面
        new_ui = QWidget()
        new_ui.setStyleSheet("background-color: lightblue;")
        layout = QVBoxLayout(new_ui)
        # 创建分组框
        ihobby_box = QGroupBox("数据与预测")#
        # 创建水平布局和对应的容器QWidget
        iv_layout = QHBoxLayout()
        iv_widget = QWidget()
        iv_widget.setLayout(iv_layout)
        iv_layout.addWidget(self.canvas[1])
        iv_layout.addWidget(self.canvas[2])
        iv_layout.addWidget(self.canvas[3])

        i2v_layout = QHBoxLayout()         
        i2v_layout.addWidget(self.canvas[4])
        i2v_layout.addWidget(self.canvas[5])
        i2v_layout.addWidget(self.canvas[6])        
        i2v_widget = QWidget()
        i2v_widget.setLayout(i2v_layout) 
        
        i3v_layout = QVBoxLayout()
        i3v_layout.addWidget(iv_widget)
        i3v_layout.addWidget(i2v_widget)

        ihobby_box.setLayout(i3v_layout)
        back_button = QPushButton('返回', new_ui)
        back_button.clicked.connect(self.switch_back_to_main_ui)
        layout.addWidget(ihobby_box) 
        layout.addWidget(back_button)
        # 添加新界面到 stacked_widget
        self.stacked_widget.addWidget(new_ui)
        # 切换到新界面
        self.stacked_widget.setCurrentWidget(new_ui)

    def switch_back_to_main_ui(self):
        # 切换回主界面
        self.stacked_widget.setCurrentIndex(0)
        self.running=True

    def start_detection(self):
        if not self.running:
            self.running = True
            self.start_button.setText('停止')  # 直接修改按钮文本
        else:
            self.running = False
            self.start_button.setText('开始')  # 直接修改按钮文本


    def stop_detection(self):
        self.switch_to_new_ui()
        if self.running:
            self.running = False
    
    def ai_start_detection(self):
        self.ai_start_button.setText("语音识别中")
        threading.Thread(target=self.update_conversation).start()

 
    def voice_start_detection(self):
        if self.voicerunning:
            # 停止播放音频
            self.stop_audio_playback()
        else:
            # 开始播放音频
            self.start_audio_playback()
    def start_audio_playback(self):
        self.voicerunning = True
        self.voice_start_button.setText("停止播放")
        # 使用一个新的线程来播放音频
        play_thread = threading.Thread(target=myaila.play_wav, args=(self.voice_output_file,))
        play_thread.start()
        # 监控播放状态的线程
        monitor_thread = threading.Thread(target=self.monitor_audio_playback)
        monitor_thread.start()

    def stop_audio_playback(self):
        # 停止播放音频
        self.voicerunning = False
        self.voice_start_button.setText("语音播放")
        myaila.stop_wav()

    def monitor_audio_playback(self):
        # 循环检查音频是否还在播放
        myaila.look_wav()
        # 音频播放完毕后，恢复按钮状态
        self.voice_start_button.setText("语音播放")
        self.voicerunning = False

    def update_conversation(self):
        # 调用语音识别，立即显示结果
        # result = "你好"  # 示例语音识别结果，实际使用时替换为 myaila.speech_to_text()
        self.ai_start_button.setText("语音识别中")
        #  result="水产养殖的PH过高怎么办"
        result=myaila.speech_to_text()
        result="水产养殖的PH过高怎么办"
        user_text = f"user：“{result}”"
        # 获取当前对话框的文本并追加用户的语音识别结果
        current_text = self.text_label.text()
        new_conversation = f"{current_text}\n{user_text}"
        self.text_label.setText(new_conversation)
        # 启动线程，异步获取 AI 响应
        threading.Thread(target=self.get_ai_response, args=(result,)).start()
        
    def get_ai_response(self, user_input):
        # 调用 AI 生成响应
        self.ai_start_button.setText("AI思考中")
        ai_text = myaila.getai(user_input)
        ai_text = ai_text.replace(" ", "").replace("\n", "")
        myaila.text_to_speech(ai_text,self.voice_output_file)
        # 在AI生成后，更新UI需要放回主线程
        self.update_ai_response(ai_text)

    def update_ai_response(self, ai_text):
        # 获取当前对话框的文本并追加 AI 响应
        current_text = self.text_label.text()
        new_conversation = f"{current_text}\nAI：“{ai_text}”"
        # 更新界面
        self.text_label.setText(new_conversation)
        self.ai_start_button.setText("询问AI")
      
    def update_frame(self, frame):
        if self.running:
            # 转换为Qt可用的格式并显示
            height, width, channel = frame.shape
            bytesPerLine = 3 * width
            qImg = QImage(frame.data, width, height, bytesPerLine, QImage.Format_RGB888)
            pixmap = QPixmap.fromImage(qImg)
            self.video_label.setPixmap(pixmap)

    def update_data(self):
        # 使用定时器或者循环持续更新数据
        self.T_label.setText(f"温度: {deal_data.T}­°C")
        self.H_label.setText(f"湿度: {deal_data.H}%")
        self.PA_label.setText(f"大气压: {deal_data.PA}pa")
        self.A_label.setText(f"海拔: {deal_data.A}m")
        self.L_label.setText(f"光强: {deal_data.L}lux")
        self.watertemp_label.setText(f"水温: {deal_data.watertemp}­°C")
        self.waterlevel_label.setText(f"水位: {deal_data.waterlevel}m")
        self.TDS_Value_label.setText(f"TDSValue: {deal_data.TDS_Value}ppm")
        self.PH_Value_label.setText(f"PHValue: {deal_data.PH_Value}")
        self.ORP_Value_label.setText(f"ORPValue: {deal_data.ORP_Value}mv")
        self.TU_Value_label.setText(f"Turbidity: {deal_data.TU_Value}NTU")
    
    def load_and_plot_data(self):
        combined_data = []  # 初始化存储所有combined_data的列表
        split_index_list = []  # 初始化存储所有split_index的列表   
        timestamps_list = [] 
        self.data_path=[
            '/home/pi/temp/dc/data/data.csv',            
            '/home/pi/temp/dc/data/TDS.csv',
            '/home/pi/temp/dc/data/PH.csv',
            '/home/pi/temp/dc/data/ORP.csv',
            '/home/pi/temp/dc/data/Turbidity.csv',
            '/home/pi/temp/dc/data/Water_Level.csv',
            '/home/pi/temp/dc/data/Water_Temperature.csv',
            '/home/pi/temp/dc/data/resdata.csv'
        ]
        in_datas = ['Temperature','TDS', 'PH', 'ORP', 'Turbidity', 'Water Level', 'Water Temperature' ]
        t_names = [ 'DATANAME','TDS Value', 'PH Value', 'ORP Value', 'Turbidity', 'Water Level', 'Water Temperature']
        c_names = ['°C','ppm', 'pH', 'mV', 'NTU', 'm', '°C']
        
        for i in range(7):  #0-6   1.2.3.4.5.6
            # 将结果追加到列表中
            combined_data_item, split_index_item, timestamps_item = lstm.deal_combined_data(self.data_path[0], in_datas[i])
            combined_data.append(combined_data_item)  # 将combined_data_item添加到列表
            split_index_list.append(split_index_item)  # 将split_index_item添加到列表
            timestamps_list.append(timestamps_item)  # 将timestamps_item添加到列表
            
        if not self.running and self.lstm_running != 0:      
            self.canvas[self.lstm_running].plot(combined_data[self.lstm_running], split_index_list[self.lstm_running], timestamps_list[self.lstm_running], t_names[self.lstm_running], c_names[self.lstm_running])
        elif self.lstm_running==0:
            # 对于canvas[7]，使用最后一个数据集的时间戳
            self.lstm_running=7
            self.canvas[7].plot(combined_data[0], split_index_list[0], timestamps_list[0], t_names[0],c_names[0])
        self.lstm_running-=1

        




# -----------------------------------------------------------------------------------------------
# 用户定义的 GStreamer 应用
# -----------------------------------------------------------------------------------------------
def run_gstreamer_app(args, user_data):
    app = GStreamerDetectionApp(args, user_data)
    app.run()
    loop = GLib.MainLoop()
    loop.run()

# -----------------------------------------------------------------------------------------------
# 主程序
# -----------------------------------------------------------------------------------------------
if __name__ == "__main__":
    user_data = user_app_callback_class()
    parser = get_default_parser()
    parser.add_argument('--labels-json', type=str, help='标签配置文件路径')
    parser.add_argument('--hef-path', type=str, help='HEF 文件路径')
    parser.add_argument('--network', type=str, default='yolov8s', help='网络类型（默认为yolov8s）')
    args = parser.parse_args()

    # # # # 启动 GStreamer 应用程序线程
    gstreamer_thread = threading.Thread(target=run_gstreamer_app, args=(args, user_data))
    gstreamer_thread.start()

    uart_tark_thread = threading.Thread(target=deal_data.uart_tark)
    uart_tark_thread.start()
    onenet_tark_thread = threading.Thread(target=deal_data.onenet_task)
    onenet_tark_thread.start()
    # 启动 Qt 应用程序
    app = QApplication(sys.argv)
    video_app = VideoApp(user_data)
    video_app.show()
    sys.exit(app.exec_())
