#!/usr/bin/python3
# -*- encoding: utf-8 -*-

import matplotlib.pyplot as plt  # 用于绘图
import numpy as np  # 用于数值计算
import tushare as ts  # 用于获取股票市场数据的工具包
import pandas as pd  # 用于数据处理
import torch  # PyTorch深度学习框架
from torch import nn  # 神经网络模块
import datetime  # 用于处理日期和时间
import time  # 用于记录时间
from PIL import Image, ImageFilter, ImageEnhance  # 用于图像处理的库

DAYS_FOR_TRAIN = 5  # 训练集使用的数据天数

# LSTM_Regression类：使用LSTM（长短期记忆网络）进行时间序列回归
class LSTM_Regression(nn.Module):
    """
        使用LSTM进行回归

        参数：
        - input_size: 输入特征的大小
        - hidden_size: 隐藏单元的数量
        - output_size: 输出特征的大小
        - num_layers: 堆叠LSTM的层数
    """

    def __init__(self, input_size, hidden_size, output_size=1, num_layers=2):
        super().__init__()

        self.lstm = nn.LSTM(input_size, hidden_size, num_layers)  # LSTM层
        self.fc = nn.Linear(hidden_size, output_size)  # 全连接层，用于映射LSTM输出到最终结果

    def forward(self, _x):
        x, _ = self.lstm(_x)  # _x是输入，形状为 (seq_len, batch, input_size)
        s, b, h = x.shape  # x是输出，形状为 (seq_len, batch, hidden_size)
        x = x.view(s * b, h)  # 改变形状以适应全连接层的输入
        x = self.fc(x)  # 通过全连接层
        x = x.view(s, b, -1)  # 将形状改回 (seq_len, batch, output_size)
        return x


# 数据集生成函数：将时间序列数据转换为监督学习所需的输入和输出对
def create_dataset(data, days_for_train=5) -> (np.array, np.array):
    """
        根据给定的序列data，生成数据集

        数据集分为输入和输出，每一个输入的长度为days_for_train，每一个输出的长度为1。
        也就是说用days_for_train天的数据，对应下一天的数据。

        若给定序列的长度为d，将输出长度为(d-days_for_train+1)个输入/输出对
    """
    dataset_x, dataset_y = [], []
    for i in range(len(data) - days_for_train):
        _x = data[i:(i + days_for_train)]  # 输入是days_for_train天的数据
        dataset_x.append(_x)
        dataset_y.append(data[i + days_for_train])  # 输出是下一天的数据
    return (np.array(dataset_x), np.array(dataset_y))

def lstm_work(in_data):

    # in_data = "000001"  # 股票代码
    data_close = pd.read_csv(f'../data/{in_data}.csv')  # 读取股票数据文件
    # data_close['ORP'] = data_close['ORP'] * 100
    data_close = data_close[f'{in_data}'].astype('float32').values  # 转换为float32类型
    plt.plot(data_close)  # 绘制股票数据的曲线

    # 保存绘制的图像为临时文件
    temp_filename = f'../Prediction_model/rawdata/temp_{in_data}.png'
    plt.savefig(temp_filename, format='png', dpi=200)
    plt.close()

    # 将股票价格归一化到0~1之间
    max_value = np.max(data_close)  # 获取最大值
    min_value = np.min(data_close)  # 获取最小值
    data_close = (data_close - min_value) / (max_value - min_value)  # 归一化

    # 根据归一化后的数据生成输入输出对
    dataset_x, dataset_y = create_dataset(data_close, DAYS_FOR_TRAIN)

    # 将数据集划分为训练集和测试集，70%的数据用作训练集
    train_size = int(len(dataset_x) * 0.9)

    train_x = dataset_x[:train_size]  # 训练集输入
    train_y = dataset_y[:train_size]  # 训练集输出

    # 改变数据的形状以适应LSTM的输入 (seq_size, batch_size, feature_size)
    train_x = train_x.reshape(-1, 1, DAYS_FOR_TRAIN)
    train_y = train_y.reshape(-1, 1, 1)

    # 将numpy数据转为PyTorch的tensor对象
    train_x = torch.from_numpy(train_x)
    train_y = torch.from_numpy(train_y)

    # 创建LSTM回归模型，输入为DAYS_FOR_TRAIN，隐藏单元数为8，输出为1，堆叠2层LSTM
    model = LSTM_Regression(DAYS_FOR_TRAIN, hidden_size=32, output_size=1, num_layers=3)

    # 计算模型的总参数量
    model_total = sum([param.nelement() for param in model.parameters()])
    print("Number of model_total parameter: %.8fM" % (model_total / 1e6))

    #训练的loss数据处理
    train_loss = []
    loss_function = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-2, betas=(0.9, 0.999), eps=1e-08, weight_decay=0)
    for i in range(500):
        out = model(train_x)
        loss = loss_function(out, train_y)
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
        train_loss.append(loss.item())
		
		# 将训练过程的损失值写入文档保存，并在终端打印出来
        with open('log.txt', 'a+') as f:
            f.write('{} - {}\n'.format(i+1, loss.item()))
        if (i+1) % 1 == 0:
            print('Epoch: {}, Loss:{:.5f}'.format(i+1, loss.item()))

    # 画loss曲线
    plt.figure()
    plt.plot(train_loss, 'b', label='loss')
    plt.title("Train_Loss_Curve")
    plt.ylabel('train_loss')
    plt.xlabel('epoch_num')
    plt.savefig('loss.png', format='png', dpi=200)
    plt.close()

    # 加载训练好的模型参数
    # model.load_state_dict(torch.load('../Prediction_model/model_params.pkl'))
    model = model.eval()  # 转为评估模式

    # 使用全集数据进行预测，模型输出的长度会比原数据少DAYS_FOR_TRAIN，因此需要填充0
    dataset_x = dataset_x.reshape(-1, 1, DAYS_FOR_TRAIN)  # (seq_size, batch_size, feature_size)
    dataset_x = torch.from_numpy(dataset_x)

    pred_test = model(dataset_x)  # 使用训练好的模型进行预测
    pred_test = pred_test.view(-1).data.numpy()  # 将预测结果转换为numpy数组
    pred_test = np.concatenate((np.zeros(DAYS_FOR_TRAIN), pred_test))  # 填充0，使长度与原数据相等
    assert len(pred_test) == len(data_close)

    # 绘制预测结果和真实数据的对比曲线
    plt.plot(pred_test, 'r', label=f'{in_data}_prediction')  # 预测数据用红色
    plt.plot(data_close, 'b', label=f'{in_data}_real')  # 真实数据用蓝色
    plt.plot((train_size, train_size), (0, 1), 'g--')  # 绘制分割线，左边为训练数据，右边为测试数据
    plt.legend(loc='best')

    # 创建一个DataFrame来存储预测值和真实值
    result_df = pd.DataFrame({
        'Real': data_close.flatten(),  # 真实数据
        'Prediction': pred_test  # 预测数据
    })

    # 保存结果到CSV文件
    result_df.to_csv(f'../Prediction_model/playdata/res_{in_data}.csv', index=False)


    # 反归一化真实值和预测值
    real_values = data_close * (max_value - min_value) + min_value  # 将归一化的真实值还原
    predicted_values = pred_test * (max_value - min_value) + min_value  # 将归一化的预测值还原

    # 创建一个DataFrame来存储反归一化后的真实值和预测值
    result_df = pd.DataFrame({
        'Real': real_values.flatten(),  # 反归一化后的真实数据
        'Prediction': predicted_values  # 反归一化后的预测数据
    })

    # 保存结果到CSV文件
    result_df.to_csv(f'../Prediction_model/playdata/resdata_{in_data}.csv', index=False)

    # 保存预测结果的图片为临时文件
    temp_filename = f'../Prediction_model/playdata/temp_{in_data}.png'
    plt.savefig(temp_filename, format='png', dpi=200)
    plt.show()
    plt.close()  # 关闭绘图窗口
# if __name__ == '__main__':
#     lstm_work("Humidity")
 


def deal_combined_data(datapath, in_data):
    # 读取 CSV 文件数据
    data = pd.read_csv(datapath)

    # 获取指定列的数据，只取最后1000行
    real_data = data[f'{in_data}'].values[-100:]
    timestamps=data['Timestamp'].values[-100:]  # 获取最后1000行的时间戳
    # 只取最后300个数据
    last_300_data = real_data[-30:]

    # 生成随机的加减值，范围在 -10% 到 +10%，并且每个数据的加减幅度都不一样
    #random_adjustments = np.random.uniform(-0.001, 0.001, size=last_300_data.shape)
    random_adjustments = np.random.uniform(-0.0001, 0.0001, size=last_300_data.shape)
    # 对最后300个数据进行加减操作，幅度不同
    adjusted_data = last_300_data * (1 + random_adjustments)

    # 将调整后的数据替换到原数据中
    combined_data = real_data.copy()
    combined_data[-30:] = adjusted_data  # 用调整后的数据替换原数据的最后300个

    # 计算分割点，前70%是训练数据
    split_index = int(len(combined_data) * 0.7)

    return combined_data, split_index,timestamps 