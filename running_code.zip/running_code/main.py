from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QStackedWidget, QLabel

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        # 创建按钮样式
        button_style = "background-color: lightblue;"

        # 创建布局
        layout = QVBoxLayout(self)

        # 创建 stacked widget 来管理多个界面
        self.stacked_widget = QStackedWidget(self)

        # 创建第一个界面
        self.first_widget = QWidget()
        first_layout = QVBoxLayout(self.first_widget)

        # 开始和停止按钮
        self.start_button = QPushButton('开始', self)
        self.start_button.setStyleSheet(button_style)
        self.start_button.setFixedSize(75, 25)

        self.stop_button = QPushButton('停止', self)
        self.stop_button.setStyleSheet(button_style)
        self.stop_button.setFixedSize(75, 25)

        first_layout.addWidget(self.start_button)
        first_layout.addWidget(self.stop_button)

        # 创建第二个界面
        self.second_widget = QWidget()
        second_layout = QVBoxLayout(self.second_widget)
        self.cover_label = QLabel("界面已被覆盖", self.second_widget)
        second_layout.addWidget(self.cover_label)

        # 添加两个界面到 stacked widget
        self.stacked_widget.addWidget(self.first_widget)
        self.stacked_widget.addWidget(self.second_widget)

        # 将 stacked widget 添加到布局
        layout.addWidget(self.stacked_widget)

        # 绑定停止按钮的事件
        self.stop_button.clicked.connect(self.switch_to_cover_screen)

    def switch_to_cover_screen(self):
        # 切换到第二个界面（覆盖界面）
        self.stacked_widget.setCurrentWidget(self.second_widget)


if __name__ == '__main__':
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec_()


"""
# 

import subprocess

def text_to_speech(text, output_file):
    """
    使用 Piper 将文本转换为语音并保存为 .wav 文件

    :param text: 要合成的文本
    :param output_file: 输出 .wav 文件路径
    """
    piper_path = "/home/pi/temp/piper-master/piper/piper"  # Piper 可执行文件的路径
    model_path = "/home/pi/temp/piper-master/piper/zh_CN-huayan-medium.onnx"  # 模型路径
    config_path = "/home/pi/temp/piper-master/piper/m_zh_CN.onnx.json"  # 配置文件路径
    
    # 使用 echo 通过管道将文本传递给 Piper
    command = f"echo '{text}' | {piper_path} --model {model_path} --config {config_path} --output_file {output_file}"

    # 执行命令
    try:
        subprocess.run(command, shell=True, check=True)
        print(f"语音合成成功，文件保存至 {output_file}")
    except subprocess.CalledProcessError as e:
        print(f"语音合成失败: {e}")

# 示例调用
text_to_speech("蘑菇是一种室内种植的食用菌，从菌丝体逐渐生长成子实体，最终成为食用菌，在适合的环境中才能更好更快地生长。蘑菇属于腐生真菌中的一种，其体内并没有叶绿素的存在，因此不能直接在光照下进行光合作用。蘑菇生长过程中，主要是将培养料中的各类营养物质作为营养来源，从而实现生长发育。培养料一般由猪粪、牛粪以及磷肥、等各类物质组成 。

蘑菇的生长主要分为菌丝生长以及子实体生长两个阶段，在不同的生长阶段，蘑菇对温度的要求也是不同的。在菌丝生长阶段，最合适的温度范围为18~20℃，子实体阶段最合适的生长温度为12~16℃。在蘑菇的各阶段生长中，温度的控制至关重要，若温度过高，菌丝的发育会加快，但非常细弱，这种菌丝易老化以及早衰，生长到子实体时会极易开伞。若是温度在4℃以下，菌丝和子实体都会停止生长
", "hello.wav")

import pygame

def play_wav(file_path):
    """
    使用 pygame 播放指定的 wav 文件
    :param file_path: wav 文件的路径
    """
    pygame.mixer.init()  # 初始化音频混音器
    pygame.mixer.music.load(file_path)  # 加载 wav 文件
    pygame.mixer.music.play()  # 播放音频

    # 等待音频播放结束
    while pygame.mixer.music.get_busy():
        pygame.time.Clock().tick(10)

# 示例调用
play_wav("hello.wav")


"""