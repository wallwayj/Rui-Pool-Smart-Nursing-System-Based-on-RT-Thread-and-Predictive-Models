#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 指定脚本运行环境和编码
# 导入所需的模块
import wave
import requests
import time
import base64
import sounddevice as sd
import numpy as np
import json
import requests
import pyttsx3
from scipy.io.wavfile import write
# import keyboard
import os
import subprocess
import pygame
import deepseek
 

# 设置音频参数
framerate = 16000  # 采样率，单位Hz
num_samples = 2000  # 每次读取的采样点数
channels = 1  # 声道数，1为单声道
sampwidth = 2  # 采样宽度，单位bytes，2表示16位
FILEPATH = 'speech.wav'  # 录音文件的保存路径

# 百度API的基本信息
 
base_url = "https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=%s&client_secret=%s"
APIKey = "hkQ82lKFhQcqOjryqboYlCC8"  # 这里的Key应该替换成有效的Key
SecretKey = "3JKP3Io4cWvW1UFZeujAepdyeIf1jSTs"  # 这里的Secret也应该替换成有效的Secret
# 构造请求令牌的URL
HOST = base_url % (APIKey, SecretKey)

# 定义获取百度API访问令牌的函数
def getToken(host):
    res = requests.post(host)
    return res.json()['access_token']

# 定义保存录音为WAV文件的函数
def save_wave_file(filepath, data, rate):
    write(filepath, rate, np.array(data))


# 录音的函数
def my_record():
    # print("按下回车键开始录音...")
    # input()  # 等待用户按下回车键
    print('正在录音...')
    # 初始化音频录制参数
    duration = 3  # 最大录音持续时间，单位秒
    recording = []
    # 定义回调函数来处理录音数据
    def callback(indata, frames, time, status):
        if status:
            print(status, flush=True)
        recording.append(indata.copy())
    # 开始录音
    with sd.InputStream(samplerate=framerate, channels=channels, dtype='int16', callback=callback):
        t_start = time.time()
        while time.time() - t_start < duration:
            # if keyboard.is_pressed('space'):
            #     break
            time.sleep(0.1)  # 等待一小段时间，以避免过度消耗CPU
    print('录音结束.')
    # 将录音数据保存到文件
    recording = np.concatenate(recording, axis=0)
    save_wave_file(FILEPATH, recording, framerate)  # 保存录音数据到文件

# 定义从文件中读取音频数据的函数
def get_audio(file):
    with open(file, 'rb') as f:
        data = f.read()
    return data

def speech_to_text():
    devpid = 1536
    my_record()  # 开始录音
    TOKEN = getToken(HOST)  # 获取API访问令牌
    speech = get_audio(FILEPATH)  # 读取录音文件
    result = speech2text(speech, TOKEN, int(devpid))  # 进行语音识别
    return result

def text_to_speech(text, output_file):
    piper_path = "/home/pi/temp/piper-master/piper/piper"  # Piper 可执行文件的路径
    model_path = "/home/pi/temp/piper-master/piper/zh_CN-huayan-medium.onnx"  # 模型路径
    config_path = "/home/pi/temp/piper-master/piper/m_zh_CN.onnx.json"  # 配置文件路径
    # 使用 echo 通过管道将文本传递给 Piper
    command = f"echo '{text}' | {piper_path} --model {model_path} --config {config_path} --output_file {output_file}"

    # 执行命令
    try:
        subprocess.run(command, shell=True, check=True)
        print(f"语音合成成功，文件保存至 {output_file}")
        # play_wav(output_file)
    except subprocess.CalledProcessError as e:
        print(f"语音合成失败: {e}")

# 示例调用
# text_to_speech("你好，欢迎使用语音合成！", "hello.wav")

def play_wav(file_path):
    """
    使用 pygame 播放指定的 wav 文件
    :param file_path: wav 文件的路径
    """
    pygame.mixer.init()  # 初始化音频混音器
    pygame.mixer.music.load(file_path)  # 加载 wav 文件
    pygame.mixer.music.play()  # 播放音频

    # 等待音频播放结束
    while pygame.mixer.music.get_busy():
        pygame.time.Clock().tick(10)

def stop_wav():     # 停止正在播放的音频
    if pygame.mixer.get_init():  # 确保 pygame 初始化过
        pygame.mixer.music.stop()
def look_wav()  :  # 循环检查音频是否还在播放
    while pygame.mixer.music.get_busy():
        time.sleep(0.1)  # 每0.1秒检查一次

# 定义将语音数据发送到百度语音识别服务并获取识别结果的函数
def speech2text(speech_data, token, dev_pid=1537):
    FORMAT = 'wav'
    RATE = '16000'
    CHANNEL = 1
    CUID = '106625741'  # 这里CUID应该设置成你的应用ID
    SPEECH = base64.b64encode(speech_data).decode('utf-8')  # 对音频数据进行Base64编码

    data = {
        'format': FORMAT,
        'rate': RATE,
        'channel': CHANNEL,
        'cuid': CUID,
        'len': len(speech_data),
        'speech': SPEECH,
        'token': token,
        'dev_pid': str(dev_pid)  # dev_pid需要转换为字符串
    }
    url = 'https://vop.baidu.com/server_api'  # 语音识别服务的URL
    headers = {'Content-Type': 'application/json'}
    print('正在识别...')
    r = requests.post(url, json=data, headers=headers)  # 发送POST请求
    Result = r.json()  # 获取JSON格式的响应
    if 'result' in Result:
        return Result['result'][0]  # 返回识别的文本结果
    else:
        return Result  # 返回整个响应，如果有错误信息也会包含在内

# 获取文心一言的token
def get_access_token():
    url = "https://aip.baidubce.com/oauth/2.0/token?client_id=Hx7BilE6xaC2CchDlNdMfPJ0&client_secret=7wHC7lq55cvpCgBCs6nruUnOJjqHXZmt&grant_type=client_credentials"
    payload = json.dumps("")
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    return response.json().get("access_token")

def getai(mess):
    aimodel="——deepseek"
    if mess=='':
        return "对不起，我没有听清您说什么."
    print("AI思考中...")

    if aimodel=="deepseek":
        response =  deepseek.get_assistant_response(mess)  
        print("\n助手:", response, "\n")
        return response
    else :
        url = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/ernie_speed?access_token=" + get_access_token()
        payload = json.dumps({
            "messages": [
                {
                    "role": "user",
                    "content": mess
                }
            ]
        })
        headers = {
            'Content-Type': 'application/json'
        }
        response = requests.request("POST", url, headers=headers, data=payload)
        data = json.loads(response.text)
        print(data['result'])
        return data['result']
        # text_to_speech(data['result'])

#if __name__ == '__main__':
def aila():
    flag = 'y'
    while flag.lower() == 'y':
        result = input("User:")
        #result = speech_to_text()
        if result:
            print(result)  # 打印识别结果
            getai(result)  # ai推理回答
        else:
            print("对不起，我没有听清您说什么.")
        flag = input('继续提问?(y/n):')  # 询问用户是否继续
