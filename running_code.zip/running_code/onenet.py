import requests
import json
import time

DEVICE_ID = "1205070184"# OneNET device_id->rpi5  API Key
API_KEY = "YJ=3hqMFW4oW1=ibQWOgR0NSEGY="
API_URL = f"http://api.heclouds.com/devices/{DEVICE_ID}/datapoints"# OneNET  API_URL  

def send_data_to_onenet(name, data):
    headers = {
        "api-key": API_KEY,
        "Content-Type": "application/json"
    }
    payload = {
        "datastreams": [
            {
                "id": name,
                "datapoints": [
                    {"value": data}    
                ]
            }
        ]
    }
    timeout_seconds = 0.5  #if time>500ms break
    try:
        response = requests.post(API_URL, headers=headers, data=json.dumps(payload), timeout=timeout_seconds)
    except requests.exceptions.Timeout: #if time>500ms break
        print(f"Failed to send {name} to OneNET within 500ms")        
'''
        if response.status_code == 200:
            print(f"{name} sent successfully to OneNET")
        else:
            print(f"Failed to send {name} to OneNET")
          

    except requests.exceptions.ConnectionError:#no link net 
        print("Failed to connect to the network")
    except Exception as e:# another error   
        print(f"Error: {e}")
'''
feeding = 1100
timex = 8301230.1830  # 初始值
def fetch_data_from_onenet():
    global feeding, timex
    headers = {
        "api-key": API_KEY,
    }

    try:
        response = requests.get(API_URL, headers=headers)
        response.raise_for_status()
        data = response.json()

        # 获取数据流
        for datastream in data.get("data", {}).get("datastreams", []):
            if datastream.get("id") == "feeding":
                datapoints = datastream.get("datapoints", [])
                if datapoints:
                    feeding = int(datapoints[0].get("value", feeding))
                else:
                    print("[OneNET] feeding 数据流为空。")

            elif datastream.get("id") == "timex":
                datapoints = datastream.get("datapoints", [])
                if datapoints:
                    timex = float(datapoints[0].get("value", timex))
                else:
                    print("[OneNET] timex 数据流为空。")

    except Exception as e:
        print(f"[ERROR] Failed to fetch onenet data: {e}")

''' 
def main():
    while True:
        data = 123          
        send_data_to_onenet("rain",123)		   
        fetch_data_from_onenet()
        if humi>50:
                send_data_to_onenet("ph",5.6)			
        time.sleep(2)

if __name__ == "__main__":
    main()
'''
